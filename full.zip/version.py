#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Versionsinformationen für E-Spektiv Hole

Dieses Modul enthält die Versionsinformationen des E-Spektiv Hole Systems.
Dazu gehören die Versionsnummer, das Releasedatum und Hinweise zu Änderungen.
"""

# Strukturierte Versionsinformation nach Semantic Versioning (https://semver.org/)
# Format: MAJOR.MINOR.PATCH
VERSION = "1.0.0"

# Releasedatum im Format YYYY-MM-DD
RELEASE_DATE = "2025-03-24"

# Build-Nummer für inkrementelle Updates
BUILD = "1"

# Codename der Version (optional)
CODENAME = "Initial Release"

# Hinweise zu Änderungen in dieser Version
CHANGELOG = [
    "Erste offizielle Version",
    "Automatische Ignorierung vorhandener Einschusslöcher beim Aktivieren der Erkennung",
    "Integration von bis zu 5 unabhängigen ROIs",
    "PDF-Berichtsgenerierung mit detaillierten Trefferinformationen",
    "Perspektivkorrektur zur Bildentzerrung",
    "Dark Mode und andere Anpassungsmöglichkeiten",
    "Vollständige Progressive Web App (PWA) Unterstützung"
]

# Unterstützte Hardware
SUPPORTED_HARDWARE = [
    "Raspberry Pi 5",
    "Raspberry Pi Camera Module 3"
]

# Minimale benötigte Abhängigkeiten
DEPENDENCIES = {
    "python": ">=3.9.0",
    "flask": ">=2.0.0",
    "opencv-python": ">=4.5.0",
    "numpy": ">=1.20.0",
    "ultralytics": ">=0.0.1",
    "reportlab": ">=3.6.0"
}

def get_version_info():
    """Gibt ein Dictionary mit allen Versionsinformationen zurück"""
    return {
        "version": VERSION,
        "release_date": RELEASE_DATE,
        "build": BUILD,
        "codename": CODENAME,
        "changelog": CHANGELOG,
        "supported_hardware": SUPPORTED_HARDWARE,
        "dependencies": DEPENDENCIES
    }

def get_version_string():
    """Gibt einen formatierten Versionsstring zurück"""
    return f"E-Spektiv Hole v{VERSION} (Build {BUILD}) - {CODENAME}"

if __name__ == "__main__":
    # Wenn das Skript direkt ausgeführt wird, Versionsinformationen anzeigen
    print(get_version_string())
    print(f"Veröffentlicht am: {RELEASE_DATE}")
    print("\nÄnderungen in dieser Version:")
    for change in CHANGELOG:
        print(f"- {change}")
    
    print("\nUnterstützte Hardware:")
    for hw in SUPPORTED_HARDWARE:
        print(f"- {hw}")