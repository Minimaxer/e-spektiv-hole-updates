#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import requests
import hashlib
import zipfile
import shutil
import tempfile
import sys
from version import VERSION, BUILD

# URL zur latest.json - muss durch Ihre GitHub URL ersetzt werden
UPDATE_CHECK_URL = "https://raw.githubusercontent.com/Minimaxer/e-spektiv-hole-updates/main/latest.json"

def check_for_updates():
    """Prüft, ob Updates verfügbar sind"""
    try:
        # Timeout auf 30 Sekunden erhöht für langsamere Verbindungen
        response = requests.get(UPDATE_CHECK_URL, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        # Aktuelle Version mit Remote-Version vergleichen
        current_version = list(map(int, VERSION.split('.')))
        latest_version = list(map(int, data["version"].split('.')))
        
        # Vergleiche Version (Major.Minor.Patch)
        for i in range(3):
            if i < len(latest_version) and i < len(current_version):
                if latest_version[i] > current_version[i]:
                    return data  # Neue Version verfügbar
                elif latest_version[i] < current_version[i]:
                    return None  # Lokale Version ist neuer (ungewöhnlich)
        
        # Wenn Versionsnummern identisch sind, prüfe Build-Nummer
        if int(data["build"]) > int(BUILD):
            return data  # Neuer Build verfügbar
        
        return None  # Keine Updates verfügbar
    except requests.exceptions.Timeout:
        print("Zeitüberschreitung bei der Verbindung zu GitHub. Bitte überprüfen Sie Ihre Internetverbindung und versuchen Sie es später erneut.")
        return None
    except requests.exceptions.ConnectionError:
        print("Verbindungsfehler. Bitte überprüfen Sie Ihre Internetverbindung.")
        return None
    except requests.exceptions.HTTPError as e:
        print(f"HTTP-Fehler bei der Update-Prüfung: {e}")
        return None
    except ValueError as e:
        print(f"Fehler beim Parsen der JSON-Antwort: {e}")
        return None
    except Exception as e:
        print(f"Unerwarteter Fehler bei der Update-Prüfung: {e}")
        return None

def download_and_verify_update(update_data):
    """Lädt ein Update herunter und verifiziert dessen Integrität"""
    try:
        temp_dir = tempfile.mkdtemp()
        zip_path = os.path.join(temp_dir, "update.zip")
        
        # Update herunterladen mit erhöhtem Timeout (60 Sekunden)
        print(f"Lade Update von {update_data['downloadUrl']} herunter...")
        response = requests.get(update_data["downloadUrl"], stream=True, timeout=60)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        with open(zip_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = (downloaded / total_size) * 100
                        if percent % 10 < 0.1:  # Alle 10% einen Status ausgeben
                            print(f"Download: {percent:.1f}% ({downloaded/1024/1024:.1f} MB / {total_size/1024/1024:.1f} MB)")
        
        print("Download abgeschlossen. Verifiziere Prüfsumme...")
        
        # Prüfsumme verifizieren
        if "md5" in update_data:
            with open(zip_path, 'rb') as f:
                file_hash = hashlib.md5(f.read()).hexdigest()
                if file_hash != update_data["md5"]:
                    print(f"MD5-Prüfsumme stimmt nicht überein! Erwartet: {update_data['md5']}, Erhalten: {file_hash}")
                    return None, None
                print("MD5-Prüfsumme korrekt.")
        
        return zip_path, temp_dir
    except requests.exceptions.Timeout:
        print("Zeitüberschreitung beim Herunterladen des Updates. Bitte überprüfen Sie Ihre Internetverbindung und versuchen Sie es später erneut.")
        return None, None
    except requests.exceptions.ConnectionError:
        print("Verbindungsfehler beim Herunterladen. Bitte überprüfen Sie Ihre Internetverbindung.")
        return None, None
    except requests.exceptions.HTTPError as e:
        print(f"HTTP-Fehler beim Herunterladen des Updates: {e}")
        return None, None
    except Exception as e:
        print(f"Unerwarteter Fehler beim Herunterladen des Updates: {e}")
        import traceback
        traceback.print_exc()
        return None, None

def install_update(zip_path, temp_dir):
    """Installiert das Update"""
    try:
        # Aktuelle Dateiliste erstellen
        current_files = []
        for root, _, files in os.walk("."):
            if ".git" in root or "/venv/" in root or "/temp/" in root:
                continue
            for filename in files:
                filepath = os.path.join(root, filename)
                if filepath.startswith("./"):
                    filepath = filepath[2:]  # "./" entfernen
                current_files.append(filepath)
        
        # Entpacken in temporäres Verzeichnis
        extract_dir = os.path.join(temp_dir, "extracted")
        os.makedirs(extract_dir, exist_ok=True)
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        
        # Konfiguration sichern
        config_backup = None
        if os.path.exists("config/settings.json"):
            with open("config/settings.json", 'r') as f:
                config_backup = f.read()
        
        # Dateien aktualisieren
        for root, _, files in os.walk(extract_dir):
            for filename in files:
                source_path = os.path.join(root, filename)
                rel_path = os.path.relpath(source_path, extract_dir)
                dest_path = rel_path
                
                # Zielverzeichnis erstellen, falls nicht vorhanden
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                
                # Datei kopieren
                shutil.copy2(source_path, dest_path)
                print(f"Aktualisiert: {dest_path}")
        
        # Konfiguration wiederherstellen, wenn diese nicht im Update enthalten war
        if config_backup and not os.path.exists(os.path.join(extract_dir, "config/settings.json")):
            os.makedirs("config", exist_ok=True)
            with open("config/settings.json", 'w') as f:
                f.write(config_backup)
            print("Bestehende Konfiguration wiederhergestellt")
        
        # Aufräumen
        shutil.rmtree(temp_dir)
        
        return True
    except Exception as e:
        print(f"Fehler beim Installieren des Updates: {e}")
        return False

def update(interactive_mode=False):
    """Hauptfunktion für den Update-Prozess"""
    print("Prüfe auf Updates...")
    update_data = check_for_updates()
    
    if not update_data:
        print("Keine Updates verfügbar.")
        return False
    
    print(f"Update verfügbar: Version {update_data['version']} (Build {update_data['build']})")
    print("Änderungen:")
    for change in update_data["changeLog"]:
        print(f"- {change}")
    
    # Wenn im interaktiven Modus, frage nach Bestätigung
    if interactive_mode:
        if input("Update jetzt installieren? (j/N): ").lower() != 'j':
            print("Update abgebrochen.")
            return False
    
    print("Lade Update herunter...")
    zip_path, temp_dir = download_and_verify_update(update_data)
    if not zip_path:
        print("Update-Download fehlgeschlagen.")
        return False
    
    print("Installiere Update...")
    if install_update(zip_path, temp_dir):
        print(f"Update auf Version {update_data['version']} (Build {update_data['build']}) erfolgreich installiert.")
        print("Starten Sie das System neu, um die Änderungen anzuwenden.")
        return True
    else:
        print("Update-Installation fehlgeschlagen.")
        return False

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        # Nur Prüfung, kein Download
        update_data = check_for_updates()
        if update_data:
            print(f"Update verfügbar: {update_data['version']} (Build {update_data['build']})")
            for change in update_data["changeLog"]:
                print(f"- {change}")
            sys.exit(0)
        else:
            print("Keine Updates verfügbar.")
            sys.exit(1)
    else:
        # Vollständiger Update-Prozess
        update(interactive_mode=True)
