// PWA Installationsskript für E-Spektiv Hole
let deferredPrompt;
let installButton;

// Beim Laden des Dokuments
document.addEventListener('DOMContentLoaded', () => {
  // Installationsbutton im DOM finden oder erstellen
  installButton = document.getElementById('installButton') || createInstallButton();
  
  // Service Worker registrieren
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/static/service-worker.js')
      .then(registration => {
        console.log('Service Worker erfolgreich registriert:', registration.scope);
      })
      .catch(error => {
        console.error('Service Worker-Registrierung fehlgeschlagen:', error);
      });
  }
});

// Event-Listener für 'beforeinstallprompt'
window.addEventListener('beforeinstallprompt', (event) => {
  // Verhindern, dass der Standard-Installations-Prompt angezeigt wird
  event.preventDefault();
  
  // Event für spätere Verwendung speichern
  deferredPrompt = event;
  
  // Installationsbutton anzeigen
  showInstallButton();
});

// Event-Listener für 'appinstalled'
window.addEventListener('appinstalled', () => {
  // Installationshinweis ausblenden, wenn die App installiert wurde
  hideInstallButton();
  
  // Tracking oder andere Aktionen nach der Installation
  console.log('E-Spektiv Hole wurde erfolgreich installiert!');
  
  // deferredPrompt zurücksetzen
  deferredPrompt = null;
});

// Funktion zum Erstellen des Installationsbuttons
function createInstallButton() {
  const button = document.createElement('button');
  button.id = 'installButton';
  button.className = 'install-button';
  button.textContent = 'App installieren';
  button.style.display = 'none';
  button.style.position = 'fixed';
  button.style.bottom = '20px';
  button.style.right = '20px';
  button.style.zIndex = '1000';
  button.style.padding = '10px 20px';
  button.style.backgroundColor = '#3B82F6';
  button.style.color = 'white';
  button.style.border = 'none';
  button.style.borderRadius = '5px';
  button.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
  button.style.cursor = 'pointer';
  
  // Event-Listener für den Button hinzufügen
  button.addEventListener('click', installApp);
  
  // Button zum Body hinzufügen
  document.body.appendChild(button);
  
  return button;
}

// Funktion zum Anzeigen des Installationsbuttons
function showInstallButton() {
  if (installButton) {
    installButton.style.display = 'block';
  }
}

// Funktion zum Ausblenden des Installationsbuttons
function hideInstallButton() {
  if (installButton) {
    installButton.style.display = 'none';
  }
}

// Funktion zum Installieren der App
function installApp() {
  if (!deferredPrompt) {
    // Wenn kein deferredPrompt vorhanden ist, können wir die App nicht installieren
    console.log('Installation ist nicht möglich');
    return;
  }
  
  // Installationsaufforderung anzeigen
  deferredPrompt.prompt();
  
  // Warten, bis der Benutzer auf den Installationshinweis reagiert hat
  deferredPrompt.userChoice.then((choiceResult) => {
    if (choiceResult.outcome === 'accepted') {
      console.log('Benutzer hat die Installation akzeptiert');
    } else {
      console.log('Benutzer hat die Installation abgelehnt');
    }
    
    // deferredPrompt zurücksetzen
    deferredPrompt = null;
  });
}