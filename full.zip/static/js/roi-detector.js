// roi-detector.js
// Funktionen für die Einschussloch-Erkennung und ROI-Auswahl

// Globale Variablen für die ROI-Auswahl
let isSelecting = false;
let startX, startY;
let currentX, currentY;
let roiSelectionActive = false;

// Globale Variable zum Speichern erkannter Einschusslöcher
let detectedHoles = [];

// Globale Variable für den Kamera-Status
let cameraOnline = false;

// Globale Variablen für die Perspektivkorrektur
let perspectiveCalibrationMode = false;
let perspectivePoints = [];

// DOM-Elemente - werden initialisiert, wenn das Dokument geladen ist
let overlay;
let roiRect;
let streamImg;
let toggleButton;
let roiButton;
let resetRoiButton;
let pdfButton;
let fullscreenHint;

// Funktion zum Umschalten der Objekterkennung
function toggleDetection() {
    const xhr = new XMLHttpRequest();
    
    xhr.open('POST', '/toggle_detection', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText);
            if (data.enabled) {
                toggleButton.textContent = 'Erkennung ausschalten';
                toggleButton.classList.remove('off');
                
                // Sofort nach erkannten Löchern fragen, wenn Erkennung aktiviert wurde
                fetchDetectedHoles(); // Sofort ausführen statt Timeout
                
                // Regelmäßige Abfrage einrichten (alle 2 Sekunden) wenn aktiviert
                if (!window.holesCheckInterval) {
                    window.holesCheckInterval = setInterval(fetchDetectedHoles, 2000);
                }
            } else {
                toggleButton.textContent = 'Erkennung einschalten';
                toggleButton.classList.add('off');
                
                // Bei Deaktivierung der Erkennung den PDF-Button deaktivieren
                pdfButton.disabled = true;
                detectedHoles = [];
                
                // Intervall-Check stoppen
                if (window.holesCheckInterval) {
                    clearInterval(window.holesCheckInterval);
                    window.holesCheckInterval = null;
                }
                
                // Manuell nochmal die erkannten Treffer abrufen, um zu bestätigen, dass sie gelöscht wurden
                setTimeout(fetchDetectedHoles, 100);
                
                // Nochmals nach einer längeren Pause, falls die erste Anfrage zu schnell war
                setTimeout(fetchDetectedHoles, 1000);
            }
        }
    };
    
    xhr.onerror = function() {
        console.error('Fehler beim Umschalten der Erkennung');
    };
    
    xhr.send();
}

// Funktion zum Aktivieren der ROI-Auswahlansicht
function toggleRoiSelection() {
    roiSelectionActive = !roiSelectionActive;
    
    if (roiSelectionActive) {
        overlay.style.display = 'block';
        roiButton.style.backgroundColor = '#FF9800';
    } else {
        overlay.style.display = 'none';
        roiButton.style.backgroundColor = '#FFC107';
    }
}

// Funktion zum Zurücksetzen der ROI
function resetRoi() {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/reset_roi', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            console.log('Alle ROIs zurückgesetzt');
            // Button-Text aktualisieren
            resetRoiButton.textContent = 'ROI zurücksetzen';
            resetRoiButton.style.backgroundColor = '#FF9800';
        }
    };
    
    xhr.send();
}

// Funktion zum Exportieren als PDF-Bericht mit Screenshot
function exportAsPDFReport() {
    // Sicherstellen, dass wir die aktuellsten Loch-Daten haben
    fetchDetectedHoles();
    
    // Kurzen Moment warten, damit die Daten aktualisiert werden können
    setTimeout(() => {
        // Prüfen, ob Daten vorhanden sind
        console.log("Bereite PDF vor, verfügbare Löcher:", detectedHoles.length);
        
        if (detectedHoles.length === 0) {
            alert("Keine Einschusslöcher zum Exportieren gefunden. Bitte aktivieren Sie die Erkennung und stellen Sie sicher, dass Einschusslöcher erkannt wurden.");
            return;
        }
        
        // Server-Endpunkt für den PDF-Export aufrufen
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/generate_pdf_report', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        
        // Aktuelles Bild als Base64 abrufen
        const canvas = document.createElement('canvas');
        canvas.width = streamImg.width;
        canvas.height = streamImg.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(streamImg, 0, 0, canvas.width, canvas.height);
        const imageData = canvas.toDataURL('image/jpeg', 0.8);
        
        // Daten senden
        const data = {
            holes: detectedHoles,
            screenshot: imageData,
            timestamp: new Date().toISOString(),
            rois: [],
            roi_count: 0
        };
        
        // Mit ROI-Server-Daten aktualisieren
        // Verwende einen synchronen Aufruf, um sicherzustellen, dass die Daten verfügbar sind
        try {
            const roiStatusXhr = new XMLHttpRequest();
            roiStatusXhr.open('GET', '/roi_status', false);  // Synchroner Aufruf
            roiStatusXhr.send();
            
            if (roiStatusXhr.status === 200) {
                const roiResponse = JSON.parse(roiStatusXhr.responseText);
                if (roiResponse && roiResponse.rois) {
                    data.rois = roiResponse.rois;
                    data.roi_count = roiResponse.count;
                    console.log("ROI-Daten für PDF geladen:", data.rois.length, "ROIs");
                }
            }
        } catch (e) {
            console.error("Fehler beim Laden der ROI-Daten:", e);
        }
        
        // Perspektivkorrektur-Status abfragen
        try {
            const perspectiveXhr = new XMLHttpRequest();
            perspectiveXhr.open('GET', '/perspective_status', false);  // Synchroner Aufruf
            perspectiveXhr.send();
            
            if (perspectiveXhr.status === 200) {
                const perspectiveData = JSON.parse(perspectiveXhr.responseText);
                data.perspective = {
                    enabled: perspectiveData.enabled,
                    complete: perspectiveData.complete
                };
                console.log("Perspektivdaten geladen - Aktiviert:", perspectiveData.enabled);
            }
        } catch (e) {
            console.error("Fehler beim Laden der Perspektivdaten:", e);
        }
        
        xhr.onload = function() {
            try {
                if (xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        // PDF im selben Fenster anzeigen statt in einem neuen Tab
                        // Erstelle eine überlagernde Anzeige
                        const pdfOverlay = document.createElement('div');
                        pdfOverlay.className = 'pdf-overlay';
                        pdfOverlay.style.position = 'fixed';
                        pdfOverlay.style.top = '0';
                        pdfOverlay.style.left = '0';
                        pdfOverlay.style.width = '100%';
                        pdfOverlay.style.height = '100%';
                        pdfOverlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
                        pdfOverlay.style.zIndex = '9999';
                        pdfOverlay.style.display = 'flex';
                        pdfOverlay.style.flexDirection = 'column';
                        
                        // Schließen-Button hinzufügen
                        const closeButton = document.createElement('button');
                        closeButton.innerHTML = 'Schließen';
                        closeButton.style.position = 'absolute';
                        closeButton.style.top = '10px';
                        closeButton.style.right = '100px';
                        closeButton.style.padding = '8px 16px';
                        closeButton.style.backgroundColor = '#f44336';
                        closeButton.style.color = 'white';
                        closeButton.style.border = 'none';
                        closeButton.style.borderRadius = '4px';
                        closeButton.style.cursor = 'pointer';
                        closeButton.style.zIndex = '10000';
                        closeButton.onclick = function() {
                            document.body.removeChild(pdfOverlay);
                        };
                        
                        // Öffnen in neuem Tab Button hinzufügen
                        const openButton = document.createElement('button');
                        openButton.innerHTML = 'In neuem Tab öffnen';
                        openButton.style.position = 'absolute';
                        openButton.style.top = '10px';
                        openButton.style.right = '210px';
                        openButton.style.padding = '8px 16px';
                        openButton.style.backgroundColor = '#4CAF50';
                        openButton.style.color = 'white';
                        openButton.style.border = 'none';
                        openButton.style.borderRadius = '4px';
                        openButton.style.cursor = 'pointer';
                        openButton.style.zIndex = '10000';
                        openButton.onclick = function() {
                            window.open(response.pdf_url, '_blank');
                        };
                        
                        // PDF-iframe erstellen
                        const pdfFrame = document.createElement('iframe');
                        pdfFrame.src = response.pdf_url;
                        pdfFrame.style.width = '100%';
                        pdfFrame.style.height = '100%';
                        pdfFrame.style.border = 'none';
                        
                        // Elemente zum Overlay hinzufügen
                        pdfOverlay.appendChild(closeButton);
                        pdfOverlay.appendChild(openButton);
                        pdfOverlay.appendChild(pdfFrame);
                        
                        // Overlay zum Dokument hinzufügen
                        document.body.appendChild(pdfOverlay);
                    } else {
                        console.error("Server-Fehler:", response.error);
                        alert("Fehler beim Erstellen des PDF-Berichts: " + response.error);
                    }
                } else {
                    console.error("HTTP-Fehler:", xhr.status, xhr.responseText);
                    alert("Fehler bei der Serveranfrage: " + xhr.status);
                }
            } catch (e) {
                console.error("Fehler beim Verarbeiten der Antwort:", e, "Rohe Antwort:", xhr.responseText);
                alert("Fehler beim Verarbeiten der Serverantwort");
            }
        };
        
        xhr.onerror = function(e) {
            console.error("Netzwerkfehler:", e);
            alert("Netzwerkfehler beim Erstellen des PDF-Berichts");
        };
        
        xhr.send(JSON.stringify(data));
        console.log("PDF-Bericht angefordert...");
    }, 100); // Kurze Verzögerung für die Datenaktualisierung
}

// Handler-Funktion, die neue Einschusslöcher vom Server empfängt
function updateDetectedHoles(holesData) {
    console.log("Erhaltene Einschusslöcher:", holesData);
    detectedHoles = holesData || [];  // Stellt sicher, dass wir immer ein Array haben
    
    // PDF-Button Status aktualisieren
    console.log("PDF-Button gefunden:", !!pdfButton);
    console.log("Anzahl erkannter Löcher:", detectedHoles.length);
    
    // Prüfen, ob ein "neuestes" Loch vom Server markiert wurde
    const newestHole = detectedHoles.find(hole => hole.is_newest === true);
    if (newestHole) {
        console.log("Neuestes Loch gefunden:", newestHole);
    }
    
    if (pdfButton) {
        // Button aktivieren, wenn Löcher gefunden wurden (auch im Perspektivmodus und mit ROIs)
        const buttonShouldBeEnabled = detectedHoles.length > 0;
        pdfButton.disabled = !buttonShouldBeEnabled;
        console.log("PDF-Button aktiviert:", buttonShouldBeEnabled);
    }
}

// Abfrage der aktuellen Einschusslöcher vom Server
function fetchDetectedHoles() {
    console.log("Hole Einschussloch-Daten vom Server...");
    const xhr = new XMLHttpRequest();
    xhr.open('GET', '/detected_holes', true);
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                const data = JSON.parse(xhr.responseText);
                console.log("Empfangene Daten:", data);
                
                // Direktes Update des PDF-Buttons
                if (data.holes) {
                    // Löcher wurden im Backend erkannt, PDF-Button aktivieren unabhängig von ROI und Perspektivenmodus
                    pdfButton.disabled = data.holes.length === 0;
                    console.log("PDF-Button direkt aktualisiert - aktiviert:", data.holes.length > 0, 
                               "Lochanzahl:", data.holes.length);
                    
                    // Zusätzliche Debug-Infos
                    if (data.holes.length > 0) {
                        // Prüfen, ob perspektivkorrigierte Löcher dabei sind
                        const hasPerspectiveCorrected = data.holes.some(hole => hole.perspective_corrected);
                        console.log("Perspektivkorrigierte Löcher vorhanden:", hasPerspectiveCorrected);
                        
                        // Prüfen, ob ROI-zugeordnete Löcher dabei sind
                        const hasRoiHoles = data.holes.some(hole => 'roi_index' in hole);
                        console.log("ROI-zugeordnete Löcher vorhanden:", hasRoiHoles);
                    }
                }
                
                updateDetectedHoles(data.holes);
            } catch (e) {
                console.error("Fehler beim Parsen der Serverdaten:", e);
                console.log("Rohdaten:", xhr.responseText);
            }
        } else {
            console.error("Fehler beim Abrufen der Einschusslöcher:", xhr.status);
        }
    };
    
    xhr.onerror = function() {
        console.error("Netzwerkfehler beim Abrufen der Einschusslöcher");
    };
    
    xhr.send();
}

// Funktion zum Aktivieren des Vollbildmodus
function enterFullscreen() {
    const element = document.documentElement;
    
    if (element.requestFullscreen) {
        element.requestFullscreen();
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
    } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
    } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen();
    }
}

// Funktionen für die ROI-Auswahl
function startSelection(e) {
    isSelecting = true;
    startX = e.clientX - overlay.getBoundingClientRect().left;
    startY = e.clientY - overlay.getBoundingClientRect().top;
    currentX = startX;
    currentY = startY;
    roiRect.style.left = startX + 'px';
    roiRect.style.top = startY + 'px';
    roiRect.style.width = '0px';
    roiRect.style.height = '0px';
    roiRect.style.display = 'block';
}

function updateSelection(e) {
    if (!isSelecting) return;
    
    currentX = e.clientX - overlay.getBoundingClientRect().left;
    currentY = e.clientY - overlay.getBoundingClientRect().top;
    
    // Rechteck-Abmessungen berechnen
    const width = Math.abs(currentX - startX);
    const height = Math.abs(currentY - startY);
    
    // Oberen linken Punkt bestimmen
    const left = Math.min(startX, currentX);
    const top = Math.min(startY, currentY);
    
    // Rechteck positionieren und dimensionieren
    roiRect.style.left = left + 'px';
    roiRect.style.top = top + 'px';
    roiRect.style.width = width + 'px';
    roiRect.style.height = height + 'px';
}

// Funktion zur präzisen Umrechnung von Bildschirmkoordinaten in Kamerakoordinaten
function calculateCameraCoordinates(screenX, screenY, screenWidth, screenHeight) {
    // Lade wichtige Dimensionsdaten
    const naturalWidth = streamImg.naturalWidth;
    const naturalHeight = streamImg.naturalHeight;
    const displayRect = streamImg.getBoundingClientRect();
    const overlayRect = overlay.getBoundingClientRect();
    
    // Berechne die Offsets zwischen dem Overlay und dem tatsächlichen Bild
    const offsetLeft = displayRect.left - overlayRect.left;
    const offsetTop = displayRect.top - overlayRect.top;
    
    // Berechne das tatsächliche Seitenverhältnis und die sichtbaren Bildabmessungen
    const imgRatio = naturalWidth / naturalHeight;
    const displayRatio = displayRect.width / displayRect.height;
    
    let visibleWidth, visibleHeight, visibleLeft, visibleTop;
    
    if (imgRatio > displayRatio) {
        // Horizontale schwarze Balken (oben und unten)
        visibleWidth = displayRect.width;
        visibleHeight = visibleWidth / imgRatio;
        visibleLeft = 0;
        visibleTop = (displayRect.height - visibleHeight) / 2;
    } else {
        // Vertikale schwarze Balken (links und rechts)
        visibleHeight = displayRect.height;
        visibleWidth = visibleHeight * imgRatio;
        visibleLeft = (displayRect.width - visibleWidth) / 2;
        visibleTop = 0;
    }
    
    // Korrigiere die Bildschirmkoordinaten um die Offsets und die Position der schwarzen Balken
    const correctedX = screenX - offsetLeft - visibleLeft;
    const correctedY = screenY - offsetTop - visibleTop;
    const correctedWidth = Math.min(screenWidth, visibleWidth - correctedX);
    const correctedHeight = Math.min(screenHeight, visibleHeight - correctedY);
    
    // Überspringe die Umrechnung, wenn die korrigierten Werte außerhalb des sichtbaren Bereichs liegen
    if (correctedX < 0 || correctedY < 0 || correctedWidth <= 0 || correctedHeight <= 0) {
        // Standardwerte für ungültige Auswahl
        return {
            x: 0,
            y: 0,
            width: Math.min(100, naturalWidth),
            height: Math.min(100, naturalHeight)
        };
    }
    
    // Umrechnung in Kamerakoordinaten (tatsächliche Pixel)
    const cameraX = Math.round((correctedX / visibleWidth) * naturalWidth);
    const cameraY = Math.round((correctedY / visibleHeight) * naturalHeight);
    const cameraWidth = Math.round((correctedWidth / visibleWidth) * naturalWidth);
    const cameraHeight = Math.round((correctedHeight / visibleHeight) * naturalHeight);
    
    // Stellen Sie sicher, dass die Koordinaten gültige Werte haben
    return {
        x: Math.max(0, Math.min(cameraX, naturalWidth - 1)),
        y: Math.max(0, Math.min(cameraY, naturalHeight - 1)),
        width: Math.max(10, Math.min(cameraWidth, naturalWidth - cameraX)),
        height: Math.max(10, Math.min(cameraHeight, naturalHeight - cameraY))
    };
}

function endSelection(e) {
    if (!isSelecting) return;
    
    isSelecting = false;
    
    // Berechnen der ausgewählten Bildschirmkoordinaten (relativ zum Overlay)
    const rectLeft = Math.min(startX, currentX);
    const rectTop = Math.min(startY, currentY);
    const rectWidth = Math.abs(currentX - startX);
    const rectHeight = Math.abs(currentY - startY);
    
    // Umrechnung in Kamerakoordinaten mit der neuen Funktion
    const cameraCoords = calculateCameraCoordinates(rectLeft, rectTop, rectWidth, rectHeight);
    
    // Debug-Ausgabe
    console.log("Bildschirmkoordinaten:", rectLeft, rectTop, rectWidth, rectHeight);
    console.log("Umgerechnet in Kamerakoordinaten:", cameraCoords);
    
    // Sende die ROI zum Server
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/set_roi', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            console.log('ROI hinzugefügt:', cameraCoords);
            
            // ROI-Button-Text mit Anzahl aktualisieren
            if (response.roi_count > 0) {
                resetRoiButton.textContent = `ROIs zurücksetzen (${response.roi_count})`;
                resetRoiButton.style.backgroundColor = '#FF5722'; // Mehr hervorheben wenn ROIs aktiv sind
            }
            
            roiSelectionActive = false;
            overlay.style.display = 'none';
            roiButton.style.backgroundColor = '#FFC107';
        } else if (xhr.status === 400) {
            // Fehlerbehandlung, z.B. wenn max. ROI-Anzahl erreicht ist
            try {
                const errorResponse = JSON.parse(xhr.responseText);
                if (errorResponse && errorResponse.error) {
                    alert(errorResponse.error);
                }
            } catch (e) {
                alert("Fehler beim Hinzufügen der ROI");
            }
        }
    };
    
    xhr.send(JSON.stringify(cameraCoords));
}

function handleKeyDown(e) {
    if (e.key === 'Escape') {
        if (roiSelectionActive) {
            roiSelectionActive = false;
            isSelecting = false;
            overlay.style.display = 'none';
            roiRect.style.display = 'none';
            roiButton.style.backgroundColor = '#FFC107';
        }
        
        if (perspectiveCalibrationMode) {
            perspectiveCalibrationMode = false;
            // Overlay entfernen, falls vorhanden
            const calibrationOverlay = document.getElementById('calibrationOverlay');
            if (calibrationOverlay) {
                calibrationOverlay.remove();
            }
            // Zurück zu den Einstellungen
            window.location.href = '/settings';
        }
    }
}

// Handler für Perspektivkorrektur-Klicks
function handlePerspectiveCalibrationClick(e) {
    if (!perspectiveCalibrationMode) return;
    
    // Berechne die Klickposition relativ zum Bild
    const rect = streamImg.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Konvertiere in Bildkoordinaten
    const imageX = Math.round((x / rect.width) * streamImg.naturalWidth);
    const imageY = Math.round((y / rect.height) * streamImg.naturalHeight);
    
    // Punkt an den Server senden
    fetch('/perspective_point', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            x: imageX,
            y: imageY
        }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            perspectivePoints = data.points;
            
            // Feedback anzeigen (aktualisierter Punktestand)
            const message = document.querySelector('.calibration-message');
            if (message) {
                const complete = data.complete;
                if (complete) {
                    message.innerHTML = `Kalibrierung abgeschlossen! (4/4 Punkte)<br><button id="endCalibrationBtn">Zurück zu den Einstellungen</button>`;
                    // Event-Listener aktualisieren
                    document.getElementById('endCalibrationBtn').addEventListener('click', function() {
                        window.location.href = '/settings';
                    });
                } else {
                    message.innerHTML = `Perspektivkorrektur: ${perspectivePoints.length}/4 Punkte gesetzt<br>Nächsten Punkt auswählen...<br><button id="endCalibrationBtn">Kalibrierung beenden</button>`;
                    // Event-Listener aktualisieren
                    document.getElementById('endCalibrationBtn').addEventListener('click', function() {
                        window.location.href = '/settings';
                    });
                }
            }
        } else {
            console.error('Fehler beim Hinzufügen des Perspektivpunkts:', data.error);
        }
    })
    .catch(error => {
        console.error('Netzwerkfehler:', error);
    });
}

function handleFullscreenChange() {
    if (!document.fullscreenElement) {
        fullscreenHint.style.display = 'flex';
        fullscreenHint.classList.remove('fade');
        
        setTimeout(function() {
            fullscreenHint.classList.add('fade');
        }, 5000);
        
        setTimeout(function() {
            fullscreenHint.style.display = 'none';
        }, 5300);
    }
}

function toggleFullscreen() {
    if (!document.fullscreenElement &&
        !document.mozFullScreenElement &&
        !document.webkitFullscreenElement &&
        !document.msFullscreenElement) {
        enterFullscreen();
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}

// Funktion zum Überprüfen, ob die Kamera online ist
function checkCameraStatus() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', '/camera_status', true);
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                const response = JSON.parse(xhr.responseText);
                const newCameraStatus = response.online;
                
                // Status hat sich geändert
                if (cameraOnline !== newCameraStatus) {
                    cameraOnline = newCameraStatus;
                    updateUIForCameraStatus();
                }
            } catch (e) {
                console.error("Fehler beim Parsen der Kamera-Status-Antwort:", e);
            }
        }
    };
    
    xhr.onerror = function() {
        // Bei Netzwerkfehler die Kamera als offline betrachten
        if (cameraOnline) {
            cameraOnline = false;
            updateUIForCameraStatus();
        }
    };
    
    xhr.send();
}

// Aktualisiert die UI-Elemente basierend auf dem Kamera-Status
function updateUIForCameraStatus() {
    if (!cameraOnline) {
        // Kamera ist offline - Buttons deaktivieren
        toggleButton.disabled = true;
        roiButton.disabled = true;
        resetRoiButton.disabled = true;
        pdfButton.disabled = true;
        
        // Visuelle Rückmeldung
        document.querySelector('.stream-img').classList.add('offline');
        
        // Statusmeldung anzeigen
        let statusOverlay = document.getElementById('cameraStatusOverlay');
        if (!statusOverlay) {
            statusOverlay = document.createElement('div');
            statusOverlay.id = 'cameraStatusOverlay';
            statusOverlay.className = 'camera-offline-overlay';
            statusOverlay.innerHTML = '<div class="camera-offline-message">Kamera offline</div>';
            document.querySelector('.video-container').appendChild(statusOverlay);
        }
    } else {
        // Kamera ist online - Buttons aktivieren
        toggleButton.disabled = false;
        roiButton.disabled = false;
        resetRoiButton.disabled = false;
        // PDF-Button nur aktivieren, wenn Löcher erkannt wurden
        pdfButton.disabled = detectedHoles.length === 0;
        
        // Visuelle Elemente entfernen
        document.querySelector('.stream-img').classList.remove('offline');
        
        // Stream-Bild neu laden, wenn die Kamera vorher offline war
        const streamImg = document.querySelector('.stream-img');
        const currentSrc = streamImg.src;
        if (currentSrc.includes('/video_feed')) {
            // Das Bild mit einem Zeitstempel neu laden, um Cache zu umgehen
            streamImg.src = '/video_feed?t=' + new Date().getTime();
        }
        
        // Statusmeldung entfernen
        const statusOverlay = document.getElementById('cameraStatusOverlay');
        if (statusOverlay) {
            statusOverlay.remove();
        }
    }
}

// Touch Event Handler
function handleTouchStart(e) {
    // Wenn Kamera offline ist oder Buttons deaktiviert sind, keine Aktion ausführen
    if (!cameraOnline || roiButton.disabled) {
        return;
    }
    
    e.preventDefault(); // Verhindert Scrolling während der Auswahl
    
    const touch = e.touches[0];
    const touchX = touch.clientX - overlay.getBoundingClientRect().left;
    const touchY = touch.clientY - overlay.getBoundingClientRect().top;
    
    // Touch-Koordinaten als Maus-Koordinaten behandeln
    isSelecting = true;
    startX = touchX;
    startY = touchY;
    currentX = touchX;
    currentY = touchY;
    
    roiRect.style.left = startX + 'px';
    roiRect.style.top = startY + 'px';
    roiRect.style.width = '0px';
    roiRect.style.height = '0px';
    roiRect.style.display = 'block';
}

function handleTouchMove(e) {
    if (!isSelecting) return;
    e.preventDefault();
    
    const touch = e.touches[0];
    currentX = touch.clientX - overlay.getBoundingClientRect().left;
    currentY = touch.clientY - overlay.getBoundingClientRect().top;
    
    // Rechteck-Abmessungen berechnen
    const width = Math.abs(currentX - startX);
    const height = Math.abs(currentY - startY);
    
    // Oberen linken Punkt bestimmen
    const left = Math.min(startX, currentX);
    const top = Math.min(startY, currentY);
    
    // Rechteck positionieren und dimensionieren
    roiRect.style.left = left + 'px';
    roiRect.style.top = top + 'px';
    roiRect.style.width = width + 'px';
    roiRect.style.height = height + 'px';
}

function handleTouchEnd(e) {
    if (!isSelecting) return;
    e.preventDefault();
    
    // Berechnen der ausgewählten Bildschirmkoordinaten (relativ zum Overlay)
    const rectLeft = Math.min(startX, currentX);
    const rectTop = Math.min(startY, currentY);
    const rectWidth = Math.abs(currentX - startX);
    const rectHeight = Math.abs(currentY - startY);
    
    // Umrechnung in Kamerakoordinaten mit der neuen Funktion
    const cameraCoords = calculateCameraCoordinates(rectLeft, rectTop, rectWidth, rectHeight);
    
    // Debug-Ausgabe
    console.log("Touch - Bildschirmkoordinaten:", rectLeft, rectTop, rectWidth, rectHeight);
    console.log("Touch - Umgerechnet in Kamerakoordinaten:", cameraCoords);
    
    // Sende die ROI zum Server
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/set_roi', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            console.log('ROI hinzugefügt (Touch):', cameraCoords);
            
            // ROI-Button-Text mit Anzahl aktualisieren
            if (response.roi_count > 0) {
                resetRoiButton.textContent = `ROIs zurücksetzen (${response.roi_count})`;
                resetRoiButton.style.backgroundColor = '#FF5722';
            }
            
            roiSelectionActive = false;
            overlay.style.display = 'none';
            roiButton.style.backgroundColor = '#FFC107';
        } else if (xhr.status === 400) {
            // Fehlerbehandlung, z.B. wenn max. ROI-Anzahl erreicht ist
            try {
                const errorResponse = JSON.parse(xhr.responseText);
                if (errorResponse && errorResponse.error) {
                    alert(errorResponse.error);
                }
            } catch (e) {
                alert("Fehler beim Hinzufügen der ROI");
            }
        }
    };
    
    xhr.send(JSON.stringify(cameraCoords));
}

// Laden der Systemeinstellungen vom Server
function loadSettings() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', '/get_settings', true);
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                const settings = JSON.parse(xhr.responseText);
                // Speichere die Einstellungen im localStorage zur späteren Verwendung
                localStorage.setItem('appSettings', JSON.stringify(settings));
                
                // Dark Mode Einstellung anwenden
                if (settings.interface && settings.interface.darkMode) {
                    document.body.classList.add('dark-mode');
                } else {
                    document.body.classList.remove('dark-mode');
                }
            } catch (e) {
                console.error("Fehler beim Parsen der Einstellungen:", e);
            }
        }
    };
    
    xhr.send();
}

// Initialisierung beim Laden der Seite
function initApp() {
    // DOM-Elemente zuweisen
    overlay = document.getElementById('roiSelectionOverlay');
    roiRect = document.getElementById('roiRect');
    streamImg = document.querySelector('.stream-img');
    toggleButton = document.getElementById('toggleButton');
    roiButton = document.getElementById('roiButton');
    resetRoiButton = document.getElementById('resetRoiButton');
    pdfButton = document.getElementById('pdfButton');
    fullscreenHint = document.getElementById('fullscreenHint');
    
    // Systemeinstellungen vom Server laden
    loadSettings();
    
    // Prüfen, ob wir im Kalibrierungsmodus sind (URL-Parameter)
    const urlParams = new URLSearchParams(window.location.search);
    perspectiveCalibrationMode = urlParams.get('calibration') === 'true';
    
    if (perspectiveCalibrationMode) {
        // UI-Hinweis für Kalibrierungsmodus anzeigen
        const calibrationOverlay = document.createElement('div');
        calibrationOverlay.id = 'calibrationOverlay';
        calibrationOverlay.className = 'calibration-overlay';
        calibrationOverlay.innerHTML = '<div class="calibration-message">Perspektivkorrektur: Klicken Sie auf die 4 Ecken in der Reihenfolge:<br>1. Oben links 2. Oben rechts 3. Unten rechts 4. Unten links<br><button id="endCalibrationBtn">Kalibrierung beenden</button></div>';
        document.querySelector('.video-container').appendChild(calibrationOverlay);
        
        // Perspektivstatus abrufen, um zu sehen, wie viele Punkte bereits gesetzt sind
        fetch('/perspective_status')
            .then(response => response.json())
            .then(data => {
                perspectivePoints = data.points;
                
                // Beim Klick auf den Videostream die Punkte hinzufügen
                streamImg.addEventListener('click', handlePerspectiveCalibrationClick);
                
                // Beenden-Button-Handler
                document.getElementById('endCalibrationBtn').addEventListener('click', function() {
                    perspectiveCalibrationMode = false;
                    // Overlay entfernen
                    document.getElementById('calibrationOverlay').remove();
                    // Zurück zu den Einstellungen
                    window.location.href = '/settings';
                });
            });
    }
    
    // Event-Listener registrieren
    overlay.addEventListener('mousedown', function(e) {
        // Nur aktiv, wenn Kamera online ist und wir nicht im Kalibrierungsmodus sind
        if (cameraOnline && !roiButton.disabled && !perspectiveCalibrationMode) {
            startSelection(e);
        }
    });
    overlay.addEventListener('mousemove', updateSelection);
    overlay.addEventListener('mouseup', endSelection);
    
    // Touch-Event-Listener für mobile Geräte
    overlay.addEventListener('touchstart', handleTouchStart);
    overlay.addEventListener('touchmove', handleTouchMove);
    overlay.addEventListener('touchend', handleTouchEnd);
    
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.querySelector('.video-container').addEventListener('dblclick', toggleFullscreen);
    
    // Prüfen, ob die Kamera online ist
    checkCameraStatus();
    
    // Status beim Laden abfragen
    const statusXhr = new XMLHttpRequest();
    statusXhr.open('GET', '/detection_status', true);
    
    statusXhr.onload = function() {
        if (statusXhr.status === 200) {
            const data = JSON.parse(statusXhr.responseText);
            
            if (data.enabled) {
                toggleButton.textContent = 'Erkennung ausschalten';
                toggleButton.classList.remove('off');
                
                // Löcher aktualisieren, da Erkennung bereits aktiviert ist
                fetchDetectedHoles();
                
                // Regelmäßige Abfrage einrichten (alle 2 Sekunden) wenn aktiviert
                if (!window.holesCheckInterval) {
                    window.holesCheckInterval = setInterval(fetchDetectedHoles, 2000);
                }
            } else {
                toggleButton.textContent = 'Erkennung einschalten';
                toggleButton.classList.add('off');
                pdfButton.disabled = true;
            }
        }
    };
    
    statusXhr.send();
    
    // ROI-Status abfragen
    const roiStatusXhr = new XMLHttpRequest();
    roiStatusXhr.open('GET', '/roi_status', true);
    
    roiStatusXhr.onload = function() {
        if (roiStatusXhr.status === 200) {
            const roiResponse = JSON.parse(roiStatusXhr.responseText);
            // ROI-Button-Text aktualisieren, um die Anzahl der ROIs anzuzeigen
            if (roiResponse.count > 0) {
                resetRoiButton.textContent = `ROIs zurücksetzen (${roiResponse.count})`;
                resetRoiButton.style.backgroundColor = '#FF5722'; // Mehr hervorheben wenn ROIs aktiv sind
            } else {
                resetRoiButton.textContent = 'ROI zurücksetzen';
                resetRoiButton.style.backgroundColor = '#FF9800';
            }
        }
    };
    
    roiStatusXhr.send();
    
    // Hinweis nach 5 Sekunden ausblenden
    setTimeout(function() {
        fullscreenHint.classList.add('fade');
    }, 5000);
    
    // Hinweis komplett entfernen nach dem Ausblenden
    setTimeout(function() {
        fullscreenHint.style.display = 'none';
    }, 5300);
    
    // Für Info Popup - nur Setup, kein automatisches Anzeigen beim Start
    setupPopupCloseOnOutsideClick();
    
    // Keine periodische Aktualisierung mehr - wird beim Aktivieren der Erkennung eingerichtet
    
    // Menü-Event-Handler hinzufügen
    document.getElementById('menuToggleButton').addEventListener('click', function(e) {
        e.stopPropagation(); // Verhindert, dass der Outside-Click-Handler direkt getriggert wird
        toggleMenu();
    });
    
    setupMenuOutsideClickHandler();
    
    // Sicherstellen, dass das Menü und Popups geschlossen werden, wenn ESC gedrückt wird
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            // Menü schließen
            if (menuOpen) {
                toggleMenu();
            }
            
            // Update-Popup schließen
            const updatePopup = document.getElementById('updatePopup');
            if (updatePopup && updatePopup.style.display === 'flex') {
                closeUpdatePopup();
            }
        }
    });
    
    // Regelmäßige Überprüfung der Kamera (alle 10 Sekunden)
    setInterval(checkCameraStatus, 10000);
}

// Funktion zum Prüfen, ob der Dark Mode aktiv ist
function isDarkModeActive() {
    // Versuche zunächst die Einstellung aus den Serverdaten zu lesen
    try {
        // Prüfen, ob es in localStorage gespeicherte Einstellungen gibt
        const settings = localStorage.getItem('appSettings');
        if (settings) {
            const parsedSettings = JSON.parse(settings);
            if (parsedSettings && parsedSettings.interface && typeof parsedSettings.interface.darkMode !== 'undefined') {
                return parsedSettings.interface.darkMode;
            }
        }
    } catch (e) {
        console.error("Fehler beim Lesen der Dark Mode Einstellung:", e);
    }
    
    // Fallback: Prüfe, ob das HTML-Element eine Klasse hat, die Dark Mode anzeigt
    return document.body.classList.contains('dark-theme') || 
           getComputedStyle(document.body).backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/)[1] < 128;
}

// Copyright Popup anzeigen
function showCopyrightPopup() {
    const popup = document.getElementById('copyrightPopup');
    // Anwendung des Dark Mode auf das Popup
    if (isDarkModeActive()) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
    popup.style.display = 'flex';
    document.addEventListener('keydown', handlePopupKeyDown);
    
    // Versionsinformationen laden und anzeigen
    const versionElement = document.getElementById('copyrightVersionInfo');
    if (versionElement) {
        fetch('/version')
            .then(response => response.json())
            .then(data => {
                versionElement.innerHTML = `Version ${data.version} (Build ${data.build}) - ${data.codename}<br>` +
                                          `Veröffentlicht am: ${data.release_date}`;
            })
            .catch(error => {
                console.error('Fehler beim Abrufen der Version:', error);
                versionElement.textContent = 'Versionsinformationen nicht verfügbar';
            });
    }
}

// Copyright Popup schließen
function closeCopyrightPopup() {
    const popup = document.getElementById('copyrightPopup');
    popup.style.display = 'none';
    document.removeEventListener('keydown', handlePopupKeyDown);
}

// Escape-Taste zum Schließen des Popups
function handlePopupKeyDown(e) {
    if (e.key === 'Escape') {
        closeCopyrightPopup();
        closePowerOptionsPopup();
    }
}

// Popup auch beim Klick außerhalb schließen
function setupPopupCloseOnOutsideClick() {
    const copyrightPopup = document.getElementById('copyrightPopup');
    const powerOptionsPopup = document.getElementById('powerOptionsPopup');
    const updatePopup = document.getElementById('updatePopup');
    
    copyrightPopup.addEventListener('click', function(e) {
        if (e.target === copyrightPopup) {
            closeCopyrightPopup();
        }
    });
    
    powerOptionsPopup.addEventListener('click', function(e) {
        if (e.target === powerOptionsPopup) {
            closePowerOptionsPopup();
        }
    });
    
    updatePopup.addEventListener('click', function(e) {
        if (e.target === updatePopup) {
            closeUpdatePopup();
        }
    });
}

// System-Optionen Popup anzeigen
function showPowerOptions() {
    const popup = document.getElementById('powerOptionsPopup');
    // Anwendung des Dark Mode auf das Popup
    if (isDarkModeActive()) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
    popup.style.display = 'flex';
    document.addEventListener('keydown', handlePopupKeyDown);
}

// System-Optionen Popup schließen
function closePowerOptionsPopup() {
    const popup = document.getElementById('powerOptionsPopup');
    popup.style.display = 'none';
    document.removeEventListener('keydown', handlePopupKeyDown);
}

// Bestätigung für Neustart/Herunterfahren
function confirmAction(action) {
    let message = '';
    if (action === 'restart') {
        message = 'Sind Sie sicher, dass Sie den Raspberry Pi neu starten möchten?';
    } else if (action === 'shutdown') {
        message = 'Sind Sie sicher, dass Sie den Raspberry Pi herunterfahren möchten?';
    }
    
    if (confirm(message)) {
        executeSystemAction(action);
    }
}

// Führt die Systemaktion durch
function executeSystemAction(action) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `/system_action/${action}`, true);
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            if (response.success) {
                if (action === 'restart') {
                    alert('Der Raspberry Pi wird neu gestartet. Die Anwendung ist in wenigen Minuten wieder verfügbar.');
                } else if (action === 'shutdown') {
                    alert('Der Raspberry Pi wird heruntergefahren.');
                }
                closePowerOptionsPopup();
            } else {
                alert(`Fehler: ${response.error}`);
            }
        } else {
            alert('Fehler bei der Ausführung der Aktion. Bitte versuchen Sie es später erneut.');
        }
    };
    
    xhr.onerror = function() {
        alert('Netzwerkfehler bei der Ausführung der Aktion. Bitte versuchen Sie es später erneut.');
    };
    
    xhr.send();
}

// Copyright-Popup beim Start kurz anzeigen und dann ausblenden
function showCopyrightOnStart() {
    setTimeout(function() {
        showCopyrightPopup();
        setTimeout(function() {
            closeCopyrightPopup();
        }, 3000);
    }, 1000);
}


// JavaScript-Funktionen für das ausklappbare Menü
let menuOpen = false;

// Menü-Toggle-Funktion
function toggleMenu() {
    menuOpen = !menuOpen;
    
    const menuButton = document.getElementById('menuToggleButton');
    const menuContent = document.getElementById('menuContent');
    
    if (menuOpen) {
        menuButton.classList.add('active');
        menuContent.classList.add('active');
        
        // Beim Öffnen des Menüs die Version abrufen und anzeigen, falls ein Versionselement existiert
        const versionElement = document.getElementById('versionInfo');
        if (versionElement) {
            fetch('/version')
                .then(response => response.json())
                .then(data => {
                    versionElement.textContent = `Version ${data.version} (Build ${data.build})`;
                })
                .catch(error => {
                    console.error('Fehler beim Abrufen der Version:', error);
                    versionElement.textContent = 'Version: unbekannt';
                });
        }
    } else {
        menuButton.classList.remove('active');
        menuContent.classList.remove('active');
    }
}

// Menü ausblenden, wenn außerhalb geklickt wird
function setupMenuOutsideClickHandler() {
    document.addEventListener('click', function(event) {
        const menuContainer = document.querySelector('.menu-container');
        const isClickInside = menuContainer.contains(event.target);
        
        if (!isClickInside && menuOpen) {
            toggleMenu();
        }
    });
}


// Update-Funktionen
function checkForUpdates() {
    const popup = document.getElementById('updatePopup');
    const updateStatus = document.getElementById('updateStatus');
    const updateDetails = document.getElementById('updateDetails');
    const updateButtons = document.getElementById('updateButtons');
    const newVersionText = document.getElementById('newVersion');
    const changelogList = document.getElementById('changelogList');
    
    // Popup anzeigen
    popup.style.display = 'flex';
    
    // Dark Mode anwenden
    if (isDarkModeActive()) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
    
    // Status zurücksetzen
    updateStatus.innerHTML = '<p>Prüfe auf Updates...</p>';
    updateDetails.style.display = 'none';
    updateButtons.style.display = 'none';
    
    // Auf Updates prüfen
    fetch('/check_updates')
        .then(response => response.json())
        .then(data => {
            if (data.updateAvailable) {
                // Update verfügbar
                updateStatus.innerHTML = '<p>Ein Update ist verfügbar!</p>';
                newVersionText.textContent = `Version ${data.version} (Build ${data.build})`;
                
                // Changelog anzeigen
                changelogList.innerHTML = '';
                if (data.changes && data.changes.length > 0) {
                    data.changes.forEach(change => {
                        const li = document.createElement('li');
                        li.textContent = change;
                        changelogList.appendChild(li);
                    });
                } else {
                    const li = document.createElement('li');
                    li.textContent = 'Keine detaillierten Änderungsinformationen verfügbar';
                    changelogList.appendChild(li);
                }
                
                // Details und Buttons anzeigen
                updateDetails.style.display = 'block';
                updateButtons.style.display = 'block';
            } else {
                // Kein Update verfügbar
                updateStatus.innerHTML = '<p>Sie verwenden bereits die neueste Version.</p>';
                
                // Timer zum automatischen Schließen nach 3 Sekunden
                setTimeout(closeUpdatePopup, 3000);
            }
        })
        .catch(error => {
            console.error('Fehler bei der Update-Prüfung:', error);
            updateStatus.innerHTML = '<p>Fehler bei der Update-Prüfung. Bitte versuchen Sie es später erneut.</p>';
            
            // Timer zum automatischen Schließen nach 3 Sekunden
            setTimeout(closeUpdatePopup, 3000);
        });
}

function installUpdate() {
    const updateStatus = document.getElementById('updateStatus');
    const updateDetails = document.getElementById('updateDetails');
    const updateButtons = document.getElementById('updateButtons');
    
    // UI aktualisieren
    updateStatus.innerHTML = '<p>Update wird installiert... Bitte warten Sie.</p>';
    updateDetails.style.display = 'none';
    updateButtons.style.display = 'none';
    
    // Update anfordern
    fetch('/update_system', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateStatus.innerHTML = '<p>Update erfolgreich installiert. Das System wird neu gestartet...</p>';
            // Seite nach 5 Sekunden neu laden
            setTimeout(() => {
                window.location.reload();
            }, 5000);
        } else {
            updateStatus.innerHTML = `<p>Fehler beim Installieren des Updates: ${data.message || 'Unbekannter Fehler'}</p>`;
            updateButtons.style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Fehler bei der Update-Installation:', error);
        updateStatus.innerHTML = '<p>Fehler bei der Update-Installation. Bitte versuchen Sie es später erneut.</p>';
        updateButtons.style.display = 'block';
    });
}

function closeUpdatePopup() {
    const popup = document.getElementById('updatePopup');
    popup.style.display = 'none';
}

// Event-Listener für den DOM-Ready-Zustand
document.addEventListener('DOMContentLoaded', initApp);
