// Service Worker für E-Spektiv Hole
const CACHE_NAME = 'e-spektiv-hole-v1';
const OFFLINE_URL = '/static/offline.html';

// App Shell-Dateien, die im Cache gespeichert werden sollen
const APP_SHELL_FILES = [
  '/',
  '/settings',
  '/static/css/styles.css',
  '/static/js/roi-detector.js',
  '/static/favicon.svg',
  '/static/index.html',
  '/static/settings.html',
  '/static/manifest.webmanifest',
  '/static/icons/icon-192x192.png',
  '/static/icons/icon-512x512.png',
  '/static/offline.html'
];

// Installation des Service Workers
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installation');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[Service Worker] Caching App Shell');
        return cache.addAll(APP_SHELL_FILES);
      })
      .then(() => {
        return self.skipWaiting();
      })
  );
});

// Aktivierung des Service Workers und Löschen alter Caches
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Aktivierung');
  event.waitUntil(
    caches.keys().then((keyList) => {
      return Promise.all(keyList.map((key) => {
        if (key !== CACHE_NAME) {
          console.log('[Service Worker] Alter Cache gelöscht:', key);
          return caches.delete(key);
        }
      }));
    })
    .then(() => {
      return self.clients.claim();
    })
  );
});

// Fetch-Ereignis: Netzwerkanfragen abfangen
self.addEventListener('fetch', (event) => {
  // Ignoriere API-Aufrufe und Daten-Streams
  if (event.request.url.includes('/video_feed') || 
      event.request.url.includes('/api/') ||
      event.request.url.includes('/detected_holes') ||
      event.request.url.includes('hole.local') ||
      event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Wenn erfolgreich, Kopie der Antwort im Cache speichern
        let responseClone = response.clone();
        caches.open(CACHE_NAME)
          .then((cache) => {
            cache.put(event.request, responseClone);
          });
        return response;
      })
      .catch(() => {
        // Bei Fehlern: Aus dem Cache bereitstellen oder Offline-Seite anzeigen
        return caches.match(event.request)
          .then((response) => {
            return response || caches.match(OFFLINE_URL);
          });
      })
  );
});

// Periodische Synchronisierung für Aktualisierung der Cache-Inhalte
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'update-cache') {
    event.waitUntil(updateCache());
  }
});

// Hilfsfunktion zum Aktualisieren des Caches
async function updateCache() {
  const cache = await caches.open(CACHE_NAME);
  for (const url of APP_SHELL_FILES) {
    try {
      await cache.add(url);
    } catch (error) {
      console.error(`Fehler beim Aktualisieren von ${url}:`, error);
    }
  }
}