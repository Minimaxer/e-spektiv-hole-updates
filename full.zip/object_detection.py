#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import cv2
import numpy as np
import threading
import os
import datetime
from ultralytics import YOLO
from picamera2 import Picamera2

class ObjectDetector:
    def __init__(self, model_path, config):
        """
        Initialisiert den Objektdetektor
        
        Args:
            model_path: Pfad zum YOLO-Modell
            config: Konfigurationsobjekt mit Einstellungen
        """
        # Konfiguration
        self.config = config
        
        # Auflösung aus der Konfiguration
        resolution_map = {
            "720p": (1280, 720),
            "1080p": (1920, 1080)
        }
        resolution = config["camera"]["resolution"]
        self.img_width, self.img_height = resolution_map.get(resolution, (1280, 720))
        
        # Erkennungskonfiguration
        self.confidence_threshold = config["camera"]["confidenceThreshold"]
        self.fps = config["camera"]["fps"]
        
        # Visualisierungsoptionen
        self.scatter_circle_color = tuple(config["visualization"]["scatterCircleColor"])
        self.scatter_circle_thickness = config["visualization"]["scatterCircleThickness"]
        self.display_scatter_circle = config["visualization"]["displayScatterCircle"]
        self.roi_border_thickness = config["visualization"].get("roiBorderThickness", 2)
        self.hole_marker_thickness = config["visualization"].get("holeMarkerThickness", 2)
        self.roi_darkening_level = config["visualization"].get("roiDarkeningLevel", 50)
        self.hole_color = tuple(config["visualization"]["holeColor"])
        self.last_hole_color = tuple(config["visualization"]["lastHoleColor"])
        self.show_only_last_hole = config["visualization"].get("showOnlyLastHole", False)
        self.show_coordinates = config["interface"]["showCoordinates"]
        
        # YOLOv11-Modell laden
        self.model = YOLO(model_path)
        print(f"Modell {model_path} geladen")
        
        # Picamera v3 initialisieren
        self.camera = Picamera2()
        sharpness_value = config["stream"]["sharpness"]
        cam_config = self.camera.create_video_configuration(
            main={"size": (self.img_width, self.img_height), "format": "RGB888"},
            controls={"FrameRate": self.fps, "Sharpness": sharpness_value}
        )
        self.camera.configure(cam_config)
        self.camera.start()
        time.sleep(2)  # Kamera aufwärmen lassen
        print(f"Picamera v3 initialisiert (Sharpness: {sharpness_value})")
        
        # Statusinformationen
        self.detection_enabled = False
        self.object_count = 0
        self.object_count_lock = threading.Lock()
        
        # ROI Verwaltung
        self.rois = []
        self.roi_lock = threading.Lock()
        
        # Erkannte Löcher
        self.detected_holes = []
        self.detected_holes_lock = threading.Lock()
        
        # Referenzlöcher - beim Start der Erkennung gespeichert
        self.reference_holes = []
        self.reference_set = False
        self.reference_lock = threading.Lock()
        
        # Neuestes Loch
        self.newest_hole_time = 0
        self.newest_hole_data = None
        
        # Perspektivkorrektur
        self.perspective_enabled = config["perspective"]["enabled"]
        self.perspective_points = config["perspective"]["points"]
        self.perspective_matrix = None
        self.perspective_lock = threading.Lock()
        
        # Perspektivmatrix initialisieren, wenn Punkte vorhanden sind
        if self.perspective_points and len(self.perspective_points) == 4:
            src_points = np.array(self.perspective_points, dtype=np.float32)
            # Zielkoordinaten (rechteckig)
            dst_width = 1000  # Feste Breite für die entzerrte Ansicht
            dst_height = 1000  # Feste Höhe für die entzerrte Ansicht
            dst_points = np.array([
                [0, 0],
                [dst_width, 0],
                [dst_width, dst_height],
                [0, dst_height]
            ], dtype=np.float32)
            self.perspective_matrix = cv2.getPerspectiveTransform(src_points, dst_points)
            
    def create_hole_object(self, box, confidence):
        """Erstellt ein Loch-Objekt aus einer Bounding-Box"""
        x1, y1, x2, y2 = box
        width = x2 - x1
        height = y2 - y1
        
        hole_data = {
            "x": x1,
            "y": y1,
            "width": width,
            "height": height,
            "confidence": confidence,
            "timestamp": time.time()
        }
        
        return hole_data

    def capture_frames(self):
        """Kontinuierlich Frames von der Kamera erfassen und verarbeiten"""
        # Import des globalen frame_buffer und frame_lock
        import sys
        # Zugriff auf die Globals des Hauptmoduls
        main_module = sys.modules['__main__']
        frame_buffer = main_module.frame_buffer
        frame_lock = main_module.frame_lock
        
        while True:
            try:
                # Frame von der Kamera abrufen
                frame = self.camera.capture_array()
                
                # Perspektivkorrektur vor der Objekterkennung anwenden
                corrected_frame = frame.copy()
                is_perspective_applied = False
                
                if self.perspective_enabled and self.perspective_matrix is not None and len(self.perspective_points) == 4:
                    try:
                        with self.perspective_lock:
                            # Bild transformieren
                            dst_width = 1000  # Gleiche Werte wie bei Erstellung der Matrix
                            dst_height = 1000
                            corrected_frame = cv2.warpPerspective(corrected_frame, self.perspective_matrix, 
                                                              (dst_width, dst_height))
                            is_perspective_applied = True
                    except Exception as e:
                        print(f"Fehler bei der Perspektivkorrektur: {e}")
                        corrected_frame = frame.copy()  # Zurück zum Original bei Fehler
                else:
                    corrected_frame = frame.copy()
                
                # Objekte im korrigierten Frame erkennen
                # Perspektivinformation übergeben, damit die ROIs korrekt angewendet werden können
                processed_frame, _ = self.detect_objects(corrected_frame, is_perspective_applied=is_perspective_applied)
                
                # Restliche Optimierungen anwenden
                optimized_frame = self.optimize_frame_for_streaming(processed_frame)
                
                # Verarbeiteten Frame zurückgeben oder im Buffer speichern
                # JPEG-Qualität reduzieren für niedrigere Bandbreite
                stream_jpeg_quality = self.config["stream"]["jpegQuality"]
                encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), stream_jpeg_quality]
                _, buffer = cv2.imencode('.jpg', optimized_frame, encode_params)
                
                # Globalen Frame-Buffer aktualisieren (mit Lock für Thread-Sicherheit)
                import sys
                main_module = sys.modules['__main__']
                with main_module.frame_lock:
                    main_module.frame_buffer = buffer.tobytes()
                
            except Exception as e:
                print(f"Fehler bei der Bildverarbeitung: {e}")
                time.sleep(0.1)  # Kurze Pause bei Fehlern
    
    def optimize_frame_for_streaming(self, frame):
        """Optimiert den Frame für das Streaming mit niedrigerer Bandbreite"""
        # Eine Kopie des Frames erstellen, damit die Originaldaten nicht verändert werden
        output_frame = frame.copy()
        
        # Die Kalibrierpunkte anzeigen, wenn sie vorhanden sind und Kalibrierungsmodus aktiv ist
        # Aber nur, wenn die Perspektivkorrektur nicht aktiv ist oder wir im Kalibrierungsmodus sind
        if not self.perspective_enabled and len(self.perspective_points) > 0:
            # Punkte anzeigen für Feedback während der Kalibrierung
            for i, point in enumerate(self.perspective_points):
                if len(point) == 2:  # Sicherstellen, dass es ein gültiger Punkt ist
                    x, y = int(point[0]), int(point[1])
                    # Farbauswahl nach Index
                    colors = [(0, 0, 255), (0, 255, 0), (255, 0, 0), (255, 255, 0)]
                    color = colors[i % len(colors)]
                    # Punkt auf dem Frame zeichnen
                    cv2.circle(output_frame, (x, y), 10, color, -1)
                    cv2.putText(output_frame, str(i+1), (x+10, y+10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
            
            # Linien zwischen den Punkten zeichnen, wenn mindestens 2 Punkte vorhanden sind
            if len(self.perspective_points) >= 2:
                for i in range(len(self.perspective_points)):
                    if i+1 < len(self.perspective_points):  # Verbinde mit dem nächsten Punkt
                        pt1 = (int(self.perspective_points[i][0]), int(self.perspective_points[i][1]))
                        pt2 = (int(self.perspective_points[i+1][0]), int(self.perspective_points[i+1][1]))
                        cv2.line(output_frame, pt1, pt2, (255, 255, 255), 2)
                
                # Verbinde letzten und ersten Punkt, wenn 4 Punkte vorhanden sind
                if len(self.perspective_points) == 4:
                    pt1 = (int(self.perspective_points[3][0]), int(self.perspective_points[3][1]))
                    pt2 = (int(self.perspective_points[0][0]), int(self.perspective_points[0][1]))
                    cv2.line(output_frame, pt1, pt2, (255, 255, 255), 2)
        
        # Frame-Größe reduzieren falls gewünscht
        stream_scale_factor = 1.0  # Oder aus der Konfiguration holen
        if stream_scale_factor != 1.0:
            new_width = int(output_frame.shape[1] * stream_scale_factor)
            new_height = int(output_frame.shape[0] * stream_scale_factor)
            output_frame = cv2.resize(output_frame, (new_width, new_height), interpolation=cv2.INTER_AREA)
        
        # In Graustufen konvertieren falls gewünscht
        stream_grayscale = self.config["stream"]["grayscale"]
        if stream_grayscale and len(output_frame.shape) == 3:
            output_frame = cv2.cvtColor(output_frame, cv2.COLOR_BGR2GRAY)
        
        return output_frame

    def detect_objects(self, frame, is_perspective_applied=False):
        """
        Führt die Objekterkennung auf einem Frame durch und gibt einen annotierten Frame zurück
        
        Args:
            frame: Das Eingabebild für die Objekterkennung
            is_perspective_applied: Gibt an, ob die Perspektivkorrektur auf den Frame angewendet wurde
            
        Returns:
            annotated_frame: Das annotierte Bild mit erkannten Objekten
            object_count: Anzahl der erkannten Objekte
        """
        # Annotiertes Bild erstellen
        annotated_frame = frame.copy()
        
        # ROIs darstellen, wenn vorhanden
        with self.roi_lock:
            if self.rois:
                # Transparente Überlagerung für Bereiche außerhalb der ROIs erstellen
                overlay = annotated_frame.copy()
                
                # Maske für den Bereich außerhalb der ROIs
                mask = np.ones(annotated_frame.shape[:2], dtype=np.uint8) * 255
                
                # Alle ROIs in der Maske berücksichtigen
                for roi in self.rois:
                    # Sicherstellen, dass die ROI-Koordinaten gültige Werte haben
                    # Wir verwenden direkt die Koordinaten - die ROIs sind bereits 
                    # für das richtige Bildformat (Original oder perspektivkorrigiert) definiert
                    x = max(0, min(roi["x"], annotated_frame.shape[1] - 1))
                    y = max(0, min(roi["y"], annotated_frame.shape[0] - 1))
                    width = max(1, min(roi["width"], annotated_frame.shape[1] - x))
                    height = max(1, min(roi["height"], annotated_frame.shape[0] - y))
                    
                    # Die ROI in der Maske ausschneiden
                    cv2.rectangle(mask, (x, y), (x + width, y + height), 0, -1)
                
                # Verdunklungsstärke berechnen (0 bis 100%)
                darkening_factor = self.roi_darkening_level / 100.0
                # Bei 0% keine Verdunklung, bei 100% vollständig schwarz
                if darkening_factor > 0:
                    # Verdunkeln der Bereiche außerhalb aller ROIs basierend auf dem Faktor
                    overlay[mask == 255] = (overlay[mask == 255] * (1 - darkening_factor)).astype(np.uint8)
                    
                    # Gewichtete Überlagerung anwenden
                    alpha = 0.5  # Mischfaktor
                    cv2.addWeighted(overlay, alpha, annotated_frame, 1.0 - alpha, 0, annotated_frame)
                
                # ROI-Rahmen zeichnen für jede ROI
                for i, roi in enumerate(self.rois):
                    # Hier gilt das gleiche - wir nutzen die bereits angepassten Koordinaten
                    x = max(0, min(roi["x"], annotated_frame.shape[1] - 1))
                    y = max(0, min(roi["y"], annotated_frame.shape[0] - 1))
                    width = max(1, min(roi["width"], annotated_frame.shape[1] - x))
                    height = max(1, min(roi["height"], annotated_frame.shape[0] - y))
                    
                    # ROI-Rahmen mit unterschiedlichen Farben für bessere Unterscheidung
                    # Farbzyklus: Gelb, Orange, Cyan
                    colors = [(0, 255, 255), (0, 165, 255), (255, 255, 0)]
                    color = colors[i % len(colors)]
                    
                    cv2.rectangle(annotated_frame, (x, y), (x + width, y + height), color, self.roi_border_thickness)
                    
                    # ROI-Nummer in der Ecke des Auswahlbereichs anzeigen
                    cv2.putText(annotated_frame, f"ROI {i+1}", (x + 5, y + 20), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        
        # Objektzähler auf 0 setzen, wenn die Erkennung deaktiviert ist
        if not self.detection_enabled:
            with self.object_count_lock:
                self.object_count = 0
        
        # Wenn Objekterkennung aktiviert ist
        elif self.detection_enabled:
            # Objekte im Frame erkennen
            results = self.model(frame, conf=self.confidence_threshold)[0]
            
            # Erkannte Objekte extrahieren und nur die behalten, die innerhalb der ROIs liegen
            all_detected_objects = results.boxes.data.tolist()
            filtered_objects = []
            
            # Bei aktivierten ROIs nur Objekte innerhalb der ROIs berücksichtigen
            if self.rois:
                # Mit ROIs: Für jede ROI die darin enthaltenen Objekte filtern
                for roi_index, roi in enumerate(self.rois):
                    roi_objects = []
                    
                    for result in all_detected_objects:
                        x1, y1, x2, y2 = result[:4]
                        
                        # Mittelpunkt der Box berechnen
                        center_x = (x1 + x2) / 2
                        center_y = (y1 + y2) / 2
                        
                        # ROI-Koordinaten bestimmen (mit oder ohne Perspektivkorrektur)
                        roi_x = max(0, roi["x"])
                        roi_y = max(0, roi["y"])
                        roi_width = max(1, roi["width"])
                        roi_height = max(1, roi["height"])
                        
                        # Prüfen, ob der Punkt in der ROI liegt
                        if (center_x >= roi_x and 
                            center_x <= roi_x + roi_width and
                            center_y >= roi_y and
                            center_y <= roi_y + roi_height):
                            roi_objects.append(result)
                            if result not in filtered_objects:  # Vermeidet Duplikate, falls ein Objekt in mehreren ROIs liegt
                                filtered_objects.append(result)
                    
                    # Farbe für diese ROI
                    colors = [(0, 255, 255), (0, 165, 255), (255, 255, 0), (0, 255, 0), (255, 0, 255)]
                    roi_color = colors[roi_index % len(colors)]
                    
                    # Streukreis für diese ROI berechnen und zeichnen, wenn Objekte vorhanden sind
                    # oder wenn nicht im "nur letzter Treffer"-Modus 
                    if len(roi_objects) >= 2 and (not self.show_only_last_hole or len(roi_objects) > 0):
                        self._calculate_and_draw_scatter_circle(
                            roi_objects, 
                            annotated_frame, 
                            color=roi_color,
                            label=f"ROI {roi_index+1}"
                        )
            else:
                # Wenn keine ROIs definiert sind, alle Objekte berücksichtigen
                filtered_objects = all_detected_objects
                
                # Streukreis für alle Objekte berechnen und zeichnen, wenn mehr als 1 Objekt vorhanden ist
                if len(filtered_objects) >= 2 and (not self.show_only_last_hole or len(filtered_objects) == 0):
                    self._calculate_and_draw_scatter_circle(filtered_objects, annotated_frame)
            
            # Zentrumskoordinaten anzeigen, wenn aktiviert
            if self.show_coordinates and filtered_objects:
                hole_centers = []
                for result in filtered_objects:
                    x1, y1, x2, y2 = map(int, result[:4])
                    hole_center_x = (x1 + x2) / 2
                    hole_center_y = (y1 + y2) / 2
                    hole_centers.append((hole_center_x, hole_center_y))
                
                if hole_centers:
                    center_x = sum(x for x, y in hole_centers) / len(hole_centers)
                    center_y = sum(y for x, y in hole_centers) / len(hole_centers)
                    
                    coords_text = f"Gesamt-Zentrum: X={int(center_x)}, Y={int(center_y)}"
                    cv2.putText(annotated_frame, coords_text, 
                              (10, annotated_frame.shape[0] - 40), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            # Neue Löcher identifizieren
            new_holes = []
            
            # Alle gefilterten Objekte durchgehen
            for result in filtered_objects:
                x1, y1, x2, y2, confidence, class_id = result
                
                # Integer-Konvertierung für OpenCV
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                
                # Loch-Daten erzeugen
                hole_data = self.create_hole_object((x1, y1, x2, y2), confidence)
                
                # Prüfen, ob es ein neues Loch ist
                is_new_hole = True
                
                # Mit existierenden Löchern vergleichen
                for existing_hole in self.detected_holes:
                    # Zentren berechnen
                    existing_center_x = existing_hole["x"] + existing_hole["width"] / 2
                    existing_center_y = existing_hole["y"] + existing_hole["height"] / 2
                    
                    current_center_x = hole_data["x"] + hole_data["width"] / 2
                    current_center_y = hole_data["y"] + hole_data["height"] / 2
                    
                    # Wenn Zentren nahe beieinander sind (< 15 Pixel), identisches Loch
                    if (abs(existing_center_x - current_center_x) < 15 and 
                        abs(existing_center_y - current_center_y) < 15):
                        is_new_hole = False
                        break
                
                # Falls Referenzlöcher gesetzt sind, auch mit diesen vergleichen
                if is_new_hole and self.reference_set:
                    with self.reference_lock:
                        for ref_hole in self.reference_holes:
                            # Zentren berechnen
                            ref_center_x = ref_hole["x"] + ref_hole["width"] / 2
                            ref_center_y = ref_hole["y"] + ref_hole["height"] / 2
                            
                            current_center_x = hole_data["x"] + hole_data["width"] / 2
                            current_center_y = hole_data["y"] + hole_data["height"] / 2
                            
                            # Wenn Zentren nahe beieinander sind (< 15 Pixel), identisches Loch - ignorieren
                            if (abs(ref_center_x - current_center_x) < 15 and 
                                abs(ref_center_y - current_center_y) < 15):
                                is_new_hole = False
                                break
                
                # Wenn neues Loch gefunden
                if is_new_hole:
                    new_holes.append({
                        "data": hole_data,
                        "coords": (x1, y1, x2, y2)
                    })
            
            # Wenn neue Löcher gefunden wurden
            if new_holes:
                # Das letzte neue Loch ist das neueste
                newest_hole = new_holes[-1]
                x1, y1, x2, y2 = newest_hole["coords"]
                
                # Neueste Loch-Daten aktualisieren
                with self.detected_holes_lock:
                    self.newest_hole_time = time.time()
                    center_x = (x1 + x2) // 2
                    center_y = (y1 + y2) // 2
                    radius = max((x2 - x1) // 2, (y2 - y1) // 2)
                    
                    self.newest_hole_data = {
                        'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                        'center_x': center_x, 'center_y': center_y, 'radius': radius,
                        'time': time.time()
                    }
                
                # Neue Löcher zur Liste hinzufügen
                for new_hole in new_holes:
                    self.detected_holes.append(new_hole["data"])
            
            # Löcher zeichnen - entweder nur das neueste oder alle
            if self.show_only_last_hole:
                # Nur das neueste Loch anzeigen
                if self.newest_hole_data:
                    center_x = self.newest_hole_data['center_x']
                    center_y = self.newest_hole_data['center_y']
                    radius = self.newest_hole_data['radius']
                    
                    # Mit spezieller Farbe zeichnen
                    color = self.last_hole_color
                    line_thickness = self.hole_marker_thickness + 1
                    
                    # Kreis mit Kreuz zeichnen
                    cv2.circle(annotated_frame, (center_x, center_y), radius, color, line_thickness)
                    cv2.line(annotated_frame, 
                            (center_x - radius, center_y), 
                            (center_x + radius, center_y), 
                            color, max(1, line_thickness // 2))
                    cv2.line(annotated_frame, 
                            (center_x, center_y - radius), 
                            (center_x, center_y + radius), 
                            color, max(1, line_thickness // 2))
            else:
                # Alle Löcher anzeigen
                for hole in self.detected_holes:
                    # Koordinaten extrahieren
                    x = hole["x"]
                    y = hole["y"]
                    width = hole["width"]
                    height = hole["height"]
                    
                    # Mittelpunkt und Radius berechnen
                    center_x = x + width // 2
                    center_y = y + height // 2
                    radius = max(width // 2, height // 2)
                    
                    # Prüfen, ob es das neueste Loch ist
                    is_newest = False
                    if self.newest_hole_data:
                        newest_center_x = self.newest_hole_data['center_x'] 
                        newest_center_y = self.newest_hole_data['center_y']
                        
                        # Abstand zum neuesten Loch prüfen
                        if (abs(center_x - newest_center_x) < 5 and 
                            abs(center_y - newest_center_y) < 5):
                            is_newest = True
                    
                    # Farbe und Linienstärke basierend auf "neuestes Loch" setzen
                    if is_newest:
                        color = self.last_hole_color
                        line_thickness = self.hole_marker_thickness + 1
                    else:
                        color = self.hole_color
                        line_thickness = self.hole_marker_thickness
                    
                    # Kreis mit Kreuz zeichnen
                    cv2.circle(annotated_frame, (center_x, center_y), radius, color, line_thickness)
                    cv2.line(annotated_frame, 
                           (center_x - radius, center_y), 
                           (center_x + radius, center_y), 
                           color, max(1, line_thickness // 2))
                    cv2.line(annotated_frame, 
                           (center_x, center_y - radius), 
                           (center_x, center_y + radius), 
                           color, max(1, line_thickness // 2))
            
            # Objektzähler aktualisieren
            with self.object_count_lock:
                self.object_count = len(self.detected_holes)
        
        # Status-Texte vorbereiten
        status_text = "Erkennung: EIN" if self.detection_enabled else "Erkennung: AUS"
        display_text = f"Anzeige: {('Nur letzter Treffer' if self.show_only_last_hole else 'Alle Treffer')}"
        roi_text = f"ROI: {len(self.rois)} AKTIV" if self.rois else "ROI: INAKTIV"
        
        # Objektzähler - immer vorbereiten, auch wenn nicht aktiv
        with self.object_count_lock:
            count_label = f"Objekte: {self.object_count if self.detection_enabled else 0}"
        
        # Status-Texte auf das Bild zeichnen (oben links, mit Hintergrund für bessere Lesbarkeit)
        # Textgrund für besseren Kontrast
        bg_color = (0, 0, 0) if not self.config["interface"]["darkMode"] else (32, 32, 32)
        
        # Farben je nach Status festlegen
        detection_color = (0, 255, 0) if self.detection_enabled else (0, 0, 255)  # Grün wenn an, Hellrot wenn aus
        roi_color = (0, 200, 200) if self.rois else (200, 200, 200)  # Gelb wenn aktiv, Grau wenn inaktiv
        count_color = (0, 150, 255) if self.object_count > 0 else (200, 200, 200)  # Orange wenn Objekte vorhanden, Grau wenn nicht
        
        # Y-Position initialisieren
        y_pos = 30
        
        # Halbtransparenter Hintergrund für den Status-Bereich
        line_spacing = 25  # Erhöhter Zeilenabstand für dickere Schrift
        bg_height = line_spacing * 4 + 10  # Höhe basierend auf Anzahl der Textzeilen + Padding (jetzt 4 Zeilen)
        
        # Längsten String ermitteln, um die Breite anzupassen - Schriftdicke 2 berücksichtigen
        text_lengths = [
            cv2.getTextSize(status_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0][0],
            cv2.getTextSize(display_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0][0],
            cv2.getTextSize(roi_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0][0],
            cv2.getTextSize(count_label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0][0]
        ]
        max_text_width = max(text_lengths)
        bg_width = max_text_width + 20  # Textbreite + etwas Padding
        
        # Overlay für Halbtransparenz erstellen
        overlay = annotated_frame.copy()
        cv2.rectangle(overlay, (5, 5), (5 + bg_width, 5 + bg_height + 10), bg_color, -1)
        cv2.rectangle(overlay, (5, 5), (5 + bg_width, 5 + bg_height + 10), (100, 100, 100), 1)
        
        # Halbtransparentes Overlay auf das Hauptbild anwenden
        alpha = 0.7  # 70% Deckkraft
        cv2.addWeighted(overlay, alpha, annotated_frame, 1 - alpha, 0, annotated_frame)
        
        # Farbe für den Anzeigemodus-Status
        display_color = (200, 50, 200) if self.show_only_last_hole else (50, 200, 200)  # Violett für "Nur letzter", Türkis für "Alle"
        
        # Statustext zeichnen mit spezifischen Farben und dickerer Schrift (Dicke 2 statt 1)
        cv2.putText(annotated_frame, status_text, (10, y_pos), cv2.FONT_HERSHEY_SIMPLEX, 0.6, detection_color, 2)
        y_pos += line_spacing
        cv2.putText(annotated_frame, display_text, (10, y_pos), cv2.FONT_HERSHEY_SIMPLEX, 0.6, display_color, 2)
        y_pos += line_spacing
        cv2.putText(annotated_frame, roi_text, (10, y_pos), cv2.FONT_HERSHEY_SIMPLEX, 0.6, roi_color, 2)
        y_pos += line_spacing
        cv2.putText(annotated_frame, count_label, (10, y_pos), cv2.FONT_HERSHEY_SIMPLEX, 0.6, count_color, 2)
        
        # Zeitstempel hinzufügen, wenn aktiviert
        if self.config["interface"]["showTimestamp"]:
            current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            timestamp_text = f"{current_time}"
            # Grau für den Zeitstempel, angepasst an Dark/Light Mode
            timestamp_color = (180, 180, 180) if not self.config["interface"]["darkMode"] else (120, 120, 120)
            cv2.putText(annotated_frame, timestamp_text, 
                       (10, annotated_frame.shape[0] - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, timestamp_color, 1)
        
        return annotated_frame, self.object_count

    def _calculate_and_draw_scatter_circle(self, objects, frame, color=None, label=None):
        """Berechnet und zeichnet einen Streukreis für die gegebenen Objekte"""
        if color is None:
            color = self.scatter_circle_color
        
        # Nur fortfahren, wenn mindestens 2 Objekte vorhanden sind
        if len(objects) < 2:
            return None
        
        # Struktur für alle Einschusslöcher mit ihren Boxen
        hole_boxes = []
        hole_centers = []
        for result in objects:
            x1, y1, x2, y2 = map(int, result[:4])
            # Jedes Loch als Box und Mittelpunkt speichern
            hole_boxes.append((x1, y1, x2, y2))
            hole_center_x = (x1 + x2) / 2
            hole_center_y = (y1 + y2) / 2
            hole_centers.append((hole_center_x, hole_center_y))
        
        # Geometrischen Mittelpunkt für die Anzeige der Koordinaten berechnen
        center_x = sum(x for x, y in hole_centers) / len(hole_centers)
        center_y = sum(y for x, y in hole_centers) / len(hole_centers)
        
        # Größten Abstand zwischen den äußersten Kanten zweier Löcher finden (echter Streukreis)
        max_distance = 0
        max_hole1 = None
        max_hole2 = None
        max_edge1 = None
        max_edge2 = None
        
        # Alle Paare von Löchern vergleichen
        for i in range(len(hole_boxes)):
            for j in range(i+1, len(hole_boxes)):
                # Boxen der beiden Löcher
                box1 = hole_boxes[i]  # (x1, y1, x2, y2) des ersten Lochs
                box2 = hole_boxes[j]  # (x1, y1, x2, y2) des zweiten Lochs
                
                # Jetzt für alle 4 Ecken der Box 1 den maximalen Abstand zu allen 4 Ecken der Box 2 berechnen
                # Liste aller Ecken von Box 1
                corners1 = [
                    (box1[0], box1[1]),  # links oben
                    (box1[2], box1[1]),  # rechts oben
                    (box1[0], box1[3]),  # links unten
                    (box1[2], box1[3])   # rechts unten
                ]
                
                # Liste aller Ecken von Box 2
                corners2 = [
                    (box2[0], box2[1]),  # links oben
                    (box2[2], box2[1]),  # rechts oben
                    (box2[0], box2[3]),  # links unten
                    (box2[2], box2[3])   # rechts unten
                ]
                
                # Alle Ecken-Kombinationen prüfen
                for c1 in corners1:
                    for c2 in corners2:
                        x1, y1 = c1
                        x2, y2 = c2
                        distance = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
                        if distance > max_distance:
                            max_distance = distance
                            max_edge1 = c1
                            max_edge2 = c2
                            max_hole1 = hole_centers[i]
                            max_hole2 = hole_centers[j]
        
        # Mitte des Streukreises (genau zwischen den beiden äußersten Kanten)
        if max_edge1 and max_edge2:
            # Mittelpunkt zwischen den äußersten Kanten verwenden
            scatter_center_x = (max_edge1[0] + max_edge2[0]) / 2
            scatter_center_y = (max_edge1[1] + max_edge2[1]) / 2
            scatter_radius = max_distance / 2
            
            # Die Zentren der beiden Löcher mit dem maximalen Abstand
            hole1_center = max_hole1
            hole2_center = max_hole2
        else:
            scatter_center_x = center_x
            scatter_center_y = center_y
            scatter_radius = 0
            hole1_center = None
            hole2_center = None
        
        # Streukreis nur zeichnen, wenn in den Einstellungen aktiviert
        if self.display_scatter_circle:
            # Streukreis zeichnen mit konfigurierbarer Farbe und Linienstärke
            cv2.circle(frame, (int(scatter_center_x), int(scatter_center_y)), 
                      int(scatter_radius), color, self.scatter_circle_thickness)
            
            # Zentroid markieren (mit invertierten RGB-Werten für Kontrast)
            inverse_color = tuple(255 - c for c in color)
            cv2.circle(frame, (int(scatter_center_x), int(scatter_center_y)), 
                      5, inverse_color, -1)
                      
            # Die beiden entferntesten Punkte hervorheben
            if max_edge1 and max_edge2:
                # Linie zwischen den entferntesten Kanten zeichnen
                cv2.line(frame, 
                       (int(max_edge1[0]), int(max_edge1[1])),
                       (int(max_edge2[0]), int(max_edge2[1])),
                       color, 1, cv2.LINE_AA)
                       
                # Die entferntesten Kanten markieren
                cv2.circle(frame, (int(max_edge1[0]), int(max_edge1[1])), 3, color, -1)
                cv2.circle(frame, (int(max_edge2[0]), int(max_edge2[1])), 3, color, -1)
            
            # Label hinzufügen, wenn angegeben (nur ROI-Nummer ohne Abmaße)
            if label:
                cv2.putText(frame, label, 
                           (int(scatter_center_x) - 20, int(scatter_center_y) - 15), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
            # Koordinaten für diese spezifische ROI anzeigen, wenn aktiviert
            if self.show_coordinates:
                coords_text = f"X={int(scatter_center_x)}, Y={int(scatter_center_y)}"
                cv2.putText(frame, coords_text, 
                           (int(scatter_center_x) - 60, int(scatter_center_y) + 20), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        
        return {
            "center_x": scatter_center_x,
            "center_y": scatter_center_y,
            "radius": scatter_radius,
            "distance": max_distance
        }

    def is_in_roi(self, box):
        """Prüft, ob eine Box innerhalb einer der ROIs liegt"""
        with self.roi_lock:
            # Wenn keine ROIs definiert sind, ist alles innerhalb
            if not self.rois:
                return True
                
            # Koordinaten der Box
            x1, y1, x2, y2 = box[:4]
            
            # Box-Mittelpunkt berechnen
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            
            # Prüfen, ob der Mittelpunkt innerhalb einer der ROIs liegt
            for roi in self.rois:
                roi_x = max(0, roi["x"])
                roi_y = max(0, roi["y"])
                roi_width = max(1, roi["width"])
                roi_height = max(1, roi["height"])
                
                if (center_x >= roi_x and 
                    center_x <= roi_x + roi_width and
                    center_y >= roi_y and
                    center_y <= roi_y + roi_height):
                    return True
            
            # Wenn der Punkt in keiner ROI liegt
            return False

    def update_config(self, new_config):
        """Aktualisiert die Konfiguration des Detektors"""
        self.config = new_config
        
        # Erkennungskonfiguration aktualisieren
        self.confidence_threshold = new_config["camera"]["confidenceThreshold"]
        self.fps = new_config["camera"]["fps"]
        
        # Visualisierungsoptionen aktualisieren
        self.scatter_circle_color = tuple(new_config["visualization"]["scatterCircleColor"])
        self.scatter_circle_thickness = new_config["visualization"]["scatterCircleThickness"]
        self.display_scatter_circle = new_config["visualization"]["displayScatterCircle"]
        self.roi_border_thickness = new_config["visualization"].get("roiBorderThickness", 2)
        self.hole_marker_thickness = new_config["visualization"].get("holeMarkerThickness", 2)
        self.roi_darkening_level = new_config["visualization"].get("roiDarkeningLevel", 50)
        self.hole_color = tuple(new_config["visualization"]["holeColor"])
        self.last_hole_color = tuple(new_config["visualization"]["lastHoleColor"])
        
        # Besondere Behandlung für showOnlyLastHole, um sicherzustellen, dass sie korrekt übernommen wird
        if "showOnlyLastHole" in new_config["visualization"]:
            self.show_only_last_hole = new_config["visualization"]["showOnlyLastHole"]
        
        self.show_coordinates = new_config["interface"]["showCoordinates"]
        
        # Kamera neu konfigurieren, falls sich Sharpness geändert hat
        sharpness_value = new_config["stream"]["sharpness"]
        self.camera.set_controls({"Sharpness": sharpness_value})
        
        # Perspektivkorrektur aktualisieren
        with self.perspective_lock:
            self.perspective_enabled = new_config["perspective"]["enabled"]
            self.perspective_points = new_config["perspective"]["points"]
            
            # Perspektivmatrix aktualisieren, wenn Punkte vorhanden sind
            if self.perspective_points and len(self.perspective_points) == 4:
                src_points = np.array(self.perspective_points, dtype=np.float32)
                # Zielkoordinaten (rechteckig)
                dst_width = 1000  # Feste Breite für die entzerrte Ansicht
                dst_height = 1000  # Feste Höhe für die entzerrte Ansicht
                dst_points = np.array([
                    [0, 0],
                    [dst_width, 0],
                    [dst_width, dst_height],
                    [0, dst_height]
                ], dtype=np.float32)
                self.perspective_matrix = cv2.getPerspectiveTransform(src_points, dst_points)
            elif not self.perspective_points:
                self.perspective_matrix = None

    def set_detection_enabled(self, enabled):
        """Aktiviert oder deaktiviert die Objekterkennung"""
        # Wenn wir gerade aktivieren, setzen wir die aktuellen Löcher als Referenz
        if enabled:
            # Aktuellen Frame holen und alle Einschusslöcher erkennen
            self.capture_reference_holes()
            
        self.detection_enabled = enabled
    
    def capture_reference_holes(self):
        """Erfasst alle aktuell sichtbaren Löcher als Referenz"""
        # Nehme ein Bild auf und erfasse alle Löcher
        frame = self.camera.capture_array()
        
        # Objekte mit YOLO erkennen
        results = self.model.predict(frame, conf=self.confidence_threshold)
        
        if not results or len(results) == 0:
            print("Keine Ergebnisse für Referenzlöcher gefunden")
            return
            
        # Nur die Ergebnisse aus dem ersten Item (es gibt immer nur einen Frame)
        boxes = results[0].boxes
        
        # Wenn keine Objekte erkannt wurden
        if len(boxes) == 0:
            print("Keine Objekte für Referenzlöcher erkannt")
            with self.reference_lock:
                self.reference_holes = []
                self.reference_set = True
            return
            
        # Extrahieren der Bounding-Boxen
        filtered_objects = []
        for i in range(len(boxes)):
            # Box-Koordinaten und Konfidenz
            x1, y1, x2, y2 = boxes.xyxy[i].tolist()
            
            # Konfidenz
            confidence = boxes.conf[i].item()
            
            # Klassen-ID
            class_id = int(boxes.cls[i].item())
            
            # Innerhalb einer ROI?
            if self.is_in_roi((x1, y1, x2, y2, confidence, class_id)):
                filtered_objects.append((x1, y1, x2, y2, confidence, class_id))
                
        # Array für die Referenzlöcher erstellen
        reference_holes = []
        
        # Referenzlöcher erstellen
        for obj in filtered_objects:
            x1, y1, x2, y2, confidence, class_id = obj
            # Integer-Konvertierung für OpenCV
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            # Loch-Daten erzeugen
            hole_data = self.create_hole_object((x1, y1, x2, y2), confidence)
            reference_holes.append(hole_data)
            
        # Referenzlöcher speichern und aktivieren
        with self.reference_lock:
            self.reference_holes = reference_holes
            self.reference_set = True
            print(f"{len(reference_holes)} Referenzlöcher erfasst")
        
    def set_display_mode(self, show_only_last_hole):
        """Setzt den Anzeigemodus (nur letzter Treffer oder alle Treffer)"""
        self.show_only_last_hole = show_only_last_hole
        
    def set_roi(self, roi):
        """Setzt eine neue ROI"""
        with self.roi_lock:
            # Bei aktivierter Perspektivkorrektur unterscheiden
            dst_width = 1000   # Konstanten für die Perspektivansicht
            dst_height = 1000
            
            # Bildgröße wählen (originale oder perspektivkorrigierte)
            if self.perspective_enabled and self.perspective_matrix is not None:
                img_width = dst_width
                img_height = dst_height
            else:
                img_width = self.img_width
                img_height = self.img_height
            
            # Sicherstellen, dass die Werte gültig sind
            x = max(0, min(int(roi.get("x", 0)), img_width - 1))
            y = max(0, min(int(roi.get("y", 0)), img_height - 1))
            width = max(10, min(int(roi.get("width", img_width)), img_width - x))
            height = max(10, min(int(roi.get("height", img_height)), img_height - y))
            
            # Minimale Größe sicherstellen (mind. 10x10 Pixel)
            if width < 10 or height < 10:
                return False
            
            # Neue ROI hinzufügen
            self.rois.append({
                "x": x,
                "y": y,
                "width": width,
                "height": height
            })
            
            return True
    
    def clear_rois(self):
        """Löscht alle ROIs"""
        with self.roi_lock:
            self.rois = []
    
    def add_detected_hole(self, hole):
        """Fügt ein erkanntes Loch zur Liste hinzu"""
        with self.detected_holes_lock:
            self.detected_holes.append(hole)
    
    def clear_detected_holes(self):
        """Löscht alle erkannten Löcher"""
        with self.detected_holes_lock:
            self.detected_holes = []
            self.newest_hole_data = None
            self.newest_hole_time = 0
            
    def reset_reference_holes(self):
        """Zurücksetzen aller Referenzlöcher"""
        with self.reference_lock:
            self.reference_holes = []
            self.reference_set = False
            print("Referenzlöcher zurückgesetzt")
            
    def get_frame(self):
        """Holt einen Frame von der Kamera"""
        frame = self.camera.capture_array()
        
        # Falls Perspektivkorrektur aktiviert ist, diese anwenden
        if self.perspective_enabled and self.perspective_matrix is not None:
            with self.perspective_lock:
                # Bild entsprechend der gespeicherten Perspektivmatrix transformieren
                frame = cv2.warpPerspective(frame, self.perspective_matrix, (self.img_width, self.img_height))
        
        return frame
        
    def close(self):
        """Schließt die Kamera und bereinigt Ressourcen"""
        if self.camera:
            self.camera.close()
            
# Ende des Moduls