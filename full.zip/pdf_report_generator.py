#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import datetime
import base64
import numpy as np
import cv2
from PIL import Image
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from reportlab.lib.units import cm

class PDFReportGenerator:
    """Klasse zur Generierung von PDF-Berichten für Einschusslöcher"""
    
    def __init__(self, config):
        """
        Initialisiert den PDF-Berichtsgenerator
        
        Args:
            config: Konfigurationsobjekt mit Einstellungen
        """
        self.config = config
        
        # Visualisierungsoptionen
        self.display_scatter_circle = config["visualization"]["displayScatterCircle"]
        self.scatter_circle_color = tuple(config["visualization"]["scatterCircleColor"])
        self.scatter_circle_thickness = config["visualization"]["scatterCircleThickness"]
        
        # Interface-Optionen
        self.show_timestamp = config["interface"]["showTimestamp"]
        self.show_coordinates = config["interface"]["showCoordinates"]
        
        # Temporäres Verzeichnis für die Berichte
        self.temp_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp')
        if not os.path.exists(self.temp_dir):
            os.makedirs(self.temp_dir)
    
    def generate_report(self, data):
        """
        Generiert einen PDF-Bericht mit den erkannten Einschusslöchern
        
        Args:
            data: Dict mit den Berichtsdaten (holes, screenshot, roi, etc.)
            
        Returns:
            Dict mit success-Status und PDF-URL oder Fehlermeldung
        """
        try:
            holes = data.get('holes', [])
            screenshot_data = data.get('screenshot', '')
            timestamp = datetime.datetime.now().isoformat()
            roi_data = data.get('roi', {"enabled": False})
            
            # Screenshot-Daten verarbeiten
            if screenshot_data and screenshot_data.startswith('data:image/jpeg;base64,'):
                screenshot_base64 = screenshot_data.replace('data:image/jpeg;base64,', '')
                screenshot_binary = base64.b64decode(screenshot_base64)
                
                # Einfaches Datums-/Zeitformat für Dateinamen
                now = datetime.datetime.now()
                timestamp_str = now.strftime('%Y%m%d_%H%M%S')
                report_filename = f"bericht_{timestamp_str}.pdf"
                screenshot_path = os.path.join(self.temp_dir, f"screenshot_{timestamp_str}.jpg")
                
                # Bildschärfe anpassen, falls konfiguriert
                sharpness = self.config["stream"]["sharpness"]
                
                # Screenshot speichern
                with open(screenshot_path, 'wb') as f:
                    f.write(screenshot_binary)
                
                # PDF-Bericht erstellen
                pdf_path = os.path.join(self.temp_dir, report_filename)
                
                # Bild für den Bericht laden, Streukreis hinzufügen und Größe anpassen
                img = Image.open(screenshot_path)
                img_width, img_height = img.size
                aspect_ratio = img_height / img_width
                
                # Streukreis und Zentroid im Bild visualisieren, wenn Löcher gefunden wurden
                if holes:
                    # Perspektivmodus und ROI-Status prüfen
                    perspective_active = data.get('perspective', {}).get('enabled', False)
                    roi_active = len(data.get('rois', [])) > 0
                    
                    # Für ROI-basierten oder Gesamt-Streukreis gruppieren wir die Löcher entsprechend
                    hole_groups = {}
                    all_holes = []  # Alle Löcher unabhängig von den ROIs
                    
                    # Prüfen, ob mindestens ein Loch perspektivkorrigiert ist
                    has_perspective_corrected = any(hole.get('perspective_corrected', False) for hole in holes)
                    
                    for hole in holes:
                        # Extraktion der Mittelpunkte für alle Löcher
                        hole_center_x = hole["x"] + hole["width"]/2
                        hole_center_y = hole["y"] + hole["height"]/2
                        all_holes.append((hole_center_x, hole_center_y))
                        
                        # ROI-Gruppierung, wenn ROI-Info verfügbar ist
                        roi_index = hole.get('roi_index')
                        if roi_index is not None:
                            if roi_index not in hole_groups:
                                hole_groups[roi_index] = []
                            hole_groups[roi_index].append((hole_center_x, hole_center_y))
                    
                    # Fallback auf alle Löcher, wenn keine ROI-Gruppen gefunden wurden
                    # oder im Perspektivmodus mit perspektivkorrigierten Löchern
                    use_all_holes = not hole_groups or (perspective_active and has_perspective_corrected)
                    
                    if use_all_holes:
                        hole_groups = {None: all_holes}  # Verwende alle Löcher als eine Gruppe
                    
                    # Informationen über Streukreise speichern
                    scatter_circles = {}
                    
                    # Streukreis für jede Gruppe berechnen
                    for group_index, centers in hole_groups.items():
                        if len(centers) < 2:
                            continue  # Zu wenig Löcher für Streukreis
                            
                        # Geometrischen Mittelpunkt berechnen
                        center_x = sum(x for x, y in centers) / len(centers)
                        center_y = sum(y for x, y in centers) / len(centers)
                        
                        # Größten Abstand zwischen zwei Löchern finden (echter Streukreis)
                        max_distance = 0
                        max_hole1 = None
                        max_hole2 = None
                        
                        # Alle Paare von Löchern vergleichen
                        for i in range(len(centers)):
                            for j in range(i+1, len(centers)):
                                x1, y1 = centers[i]
                                x2, y2 = centers[j]
                                distance = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
                                if distance > max_distance:
                                    max_distance = distance
                                    max_hole1 = (x1, y1)
                                    max_hole2 = (x2, y2)
                        
                        # Mitte des Streukreises (zwischen den beiden am weitesten entfernten Löchern)
                        if max_hole1 and max_hole2:
                            scatter_center_x = (max_hole1[0] + max_hole2[0]) / 2
                            scatter_center_y = (max_hole1[1] + max_hole2[1]) / 2
                            scatter_radius = max_distance / 2
                            
                            # Streukreis für diese Gruppe speichern
                            scatter_circles[group_index] = {
                                'center_x': scatter_center_x,
                                'center_y': scatter_center_y,
                                'radius': scatter_radius,
                                'max_distance': max_distance,
                                'max_hole1': max_hole1,
                                'max_hole2': max_hole2
                            }
                    
                    # Verwende für die Bildbeschriftung den Haupt-Streukreis
                    # (entweder der einzige Streukreis oder der für None, wenn mehrere existieren)
                    main_scatter = scatter_circles.get(None)
                    if main_scatter is None and scatter_circles:
                        # Wenn kein None-Streukreis, nimm den ersten verfügbaren
                        main_scatter = next(iter(scatter_circles.values()))
                    
                    if main_scatter:
                        scatter_center_x = main_scatter['center_x']
                        scatter_center_y = main_scatter['center_y']
                        scatter_radius = main_scatter['radius']
                        max_hole1 = main_scatter['max_hole1']
                        max_hole2 = main_scatter['max_hole2']
                        center_x = scatter_center_x  # Für Koordinatenanzeige
                        center_y = scatter_center_y
                    else:
                        # Fallback - Mittelpunkt aller Löcher wenn kein Streukreis berechnet werden konnte
                        if all_holes:
                            center_x = sum(x for x, y in all_holes) / len(all_holes)
                            center_y = sum(y for x, y in all_holes) / len(all_holes)
                            scatter_center_x = center_x
                            scatter_center_y = center_y
                            scatter_radius = 0
                            max_hole1 = None
                            max_hole2 = None
                        else:
                            # Sollte nie passieren, da wir bereits geprüft haben, dass holes nicht leer ist
                            center_x = img_width / 2
                            center_y = img_height / 2
                            scatter_center_x = center_x
                            scatter_center_y = center_y
                            scatter_radius = 0
                            max_hole1 = None
                            max_hole2 = None
                    
                    # Streukreis und metrische Visualisierung im Bild
                    img_np = np.array(img)
                    
                    # Nur Streukreis zeichnen, wenn in den Einstellungen aktiviert
                    if self.display_scatter_circle:
                        # Konfigurierbare Farbe und Dicke für den Streukreis
                        cv2.circle(img_np, (int(scatter_center_x), int(scatter_center_y)), int(scatter_radius), 
                                  self.scatter_circle_color, self.scatter_circle_thickness)
                        
                        # Zentroid mit invertierten Farben für Kontrast
                        inverse_color = tuple(255 - c for c in self.scatter_circle_color)
                        cv2.circle(img_np, (int(scatter_center_x), int(scatter_center_y)), 5, inverse_color, -1)
                        
                        # Die beiden entferntesten Löcher hervorheben
                        if max_hole1 and max_hole2:
                            # Linie zwischen den entferntesten Löchern zeichnen
                            cv2.line(img_np, 
                                  (int(max_hole1[0]), int(max_hole1[1])),
                                  (int(max_hole2[0]), int(max_hole2[1])),
                                  self.scatter_circle_color, 1, cv2.LINE_AA)
                        
                        # Text mit einfachem Hinweis hinzufügen
                        font = cv2.FONT_HERSHEY_SIMPLEX
                        cv2.putText(img_np, "Streukreis manuell bestimmen", 
                                   (int(center_x - 150), int(center_y - 20)), 
                                   font, 0.7, (255, 255, 255), 2)
                    else:
                        font = cv2.FONT_HERSHEY_SIMPLEX  # Definiere Font für den Fall, dass es später benötigt wird
                    
                    # Datum und Uhrzeit hinzufügen, wenn aktiviert
                    if self.show_timestamp:
                        timestamp_display = datetime.datetime.now().strftime("%d.%m.%Y %H:%M")
                        cv2.putText(img_np, timestamp_display, 
                                  (int(img_width - 200), int(img_height - 20)), 
                                  font, 0.5, (255, 255, 255), 1)
                    
                    # Koordinaten anzeigen, wenn aktiviert
                    if self.show_coordinates:
                        coordinates_text = f"Zentrum: X={int(center_x)}, Y={int(center_y)}"
                        cv2.putText(img_np, coordinates_text, 
                                  (10, img_height - 20), 
                                  font, 0.5, (255, 255, 255), 1)
                    
                    img = Image.fromarray(img_np)
                
                # PDF erstellen
                c = canvas.Canvas(pdf_path, pagesize=A4)
                width, height = A4
                
                # Titel
                c.setFont("Helvetica-Bold", 16)
                c.drawString(2*cm, height - 2*cm, "E-Spektiv Hole - Schießbericht")
                
                # Datum und Uhrzeit
                c.setFont("Helvetica", 12)
                # Aktuelle Zeit verwenden
                report_date = now.strftime('%d.%m.%Y %H:%M:%S')
                c.drawString(2*cm, height - 3*cm, f"Datum: {report_date}")
                
                # Bild einfügen - Bildgröße reduzieren, damit mehr Platz für Inhalt bleibt
                pdf_img_width = width - 4*cm
                # Bildgröße anpassen: auf maximal 40% der Seitenhöhe begrenzen
                max_img_height = height * 0.4
                pdf_img_height = pdf_img_width * aspect_ratio
                if pdf_img_height > max_img_height:
                    pdf_img_height = max_img_height
                    pdf_img_width = pdf_img_height / aspect_ratio
                
                c.drawImage(screenshot_path, 2*cm, height - pdf_img_height - 4*cm, 
                           width=pdf_img_width, height=pdf_img_height)
                
                # Für ROI und Löcher ein zwei-spalten Layout erstellen
                
                # Position für die Überschrift der Loch-Tabelle
                c.setFont("Helvetica-Bold", 12)
                c.drawString(2*cm, height - pdf_img_height - 4.5*cm, f"Erkannte Einschusslöcher: {len(holes)}")
                
                # Feste y-Position für den Start aller weiteren Elemente
                content_y_start = height - pdf_img_height - 5*cm
                
                # Löcher in ein Wörterbuch nach ROI gruppieren
                roi_holes = {}
                for hole in holes:
                    # Sichere Prüfung, ob roi_index existiert
                    roi_index = None
                    if isinstance(hole, dict) and 'roi_index' in hole:
                        roi_index = hole['roi_index']
                        
                    if roi_index is not None:
                        if roi_index not in roi_holes:
                            roi_holes[roi_index] = []
                        roi_holes[roi_index].append(hole)
                
                # ROI-Informationen auf der rechten Seite
                if 'rois' in data and isinstance(data['rois'], list) and len(data['rois']) > 0:
                    # Leerer Block, um Indentierungsfehler zu vermeiden
                    pass
                
                # Freien Platz für den Rest des Dokuments berechnen
                # Mehr Platz zwischen Bild und Tabelle lassen
                content_y_start = height - pdf_img_height - 5.5*cm  # Zusätzliche Zeile Abstand
                content_bottom = content_y_start - 1*cm
                
                # ROI-Tabelle erstellen
                if 'rois' in data and isinstance(data['rois'], list) and len(data['rois']) > 0:
                    # ROI-Überschrift
                    c.setFont("Helvetica-Bold", 12)
                    c.drawString(2*cm, content_y_start, "ROI-Informationen")
                    
                    # Sammle und gruppiere alle Löcher nach ROIs
                    # Zuerst ein neues Dictionary für ROI-Lochgruppen erstellen
                    roi_holes = {}
                    # Auch ein Gesamtstreukreis für alle Löcher
                    all_holes_centers = []
                    
                    # Prüfen, ob Perspektivkorrektur aktiviert ist
                    perspective_active = data.get('perspective', {}).get('enabled', False)
                    
                    # Gruppiere alle Löcher
                    for hole in holes:
                        # Berechne Mittelpunkt für jedes Loch für den Gesamtstreukreis
                        center_x = hole["x"] + hole["width"]/2
                        center_y = hole["y"] + hole["height"]/2
                        all_holes_centers.append((center_x, center_y))
                        
                        # Sichere Prüfung, ob roi_index existiert
                        roi_index = None
                        if isinstance(hole, dict) and 'roi_index' in hole:
                            # roi_index muss als int interpretiert werden (nicht als String)
                            try:
                                roi_index = int(hole['roi_index'])
                            except (ValueError, TypeError):
                                roi_index = hole['roi_index']
                            
                            # Füge das Loch zu seiner ROI-Gruppe hinzu
                            if roi_index not in roi_holes:
                                roi_holes[roi_index] = []
                            roi_holes[roi_index].append(hole)
                    
                    # Spezialbehandlung für Perspektivkorrektur
                    has_perspective_holes = perspective_active and any(h.get('perspective_corrected', False) for h in holes)
                    
                    # Im Perspektivmodus haben die Einschusslöcher bereits ROI-Indizes
                    # Wir müssen sie jetzt nur nach ROI gruppieren
                    if has_perspective_holes:
                        # Spezieller ROI-Index für den Gesamtstreukreis
                        roi_holes["gesamt"] = holes
                        
                        # Zusätzlich: Alle Löcher nach ihren ROI-Indizes gruppieren
                        for hole in holes:
                            if 'roi_index' in hole and hole['roi_index'] != "gesamt":
                                # ROI-Index als Integer sicherstellen
                                try:
                                    roi_idx = int(hole['roi_index'])
                                    if roi_idx not in roi_holes:
                                        roi_holes[roi_idx] = []
                                    roi_holes[roi_idx].append(hole)
                                except:
                                    pass  # Ungültiger ROI-Index wird ignoriert
                    
                    # Tabellendaten vorbereiten - mit Gesamtstreukreis als erste Zeile
                    data_rows = [["ROI #", "Farbe", "Einschüsse", "Streukreis (px)"]]
                    
                    # Zuerst den Gesamtstreukreis berechnen und hinzufügen (immer)
                    scatter_info = "-"
                    if len(all_holes_centers) >= 2:
                        # Größten Abstand zwischen zwei Löchern finden
                        max_distance = 0
                        for i in range(len(all_holes_centers)):
                            for j in range(i+1, len(all_holes_centers)):
                                x1, y1 = all_holes_centers[i]
                                x2, y2 = all_holes_centers[j]
                                distance = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
                                max_distance = max(max_distance, distance)
                        
                        scatter_info = f"Ø {int(max_distance)} px"
                    
                    # Erste Zeile ist immer der Gesamtstreukreis
                    data_rows.append([
                        "Gesamt",
                        "Blau",
                        str(len(holes)),
                        scatter_info
                    ])
                    
                    # Farbnamen für die ROIs
                    color_names = ["Gelb", "Orange", "Cyan", "Grün", "Magenta"]
                    
                    # ROI-spezifische Zeilen
                    for i, roi in enumerate(data['rois']):
                        # ROI-Nummer und Farbe
                        color_name = color_names[i % len(color_names)]
                        
                        # Löcher für diese ROI finden
                        holes_in_roi = roi_holes.get(i, [])
                        
                        # Streukreis berechnen
                        scatter_info = "-"
                        if len(holes_in_roi) >= 2:
                            # Mittelpunkte der Löcher sammeln
                            hole_centers = []
                            for hole in holes_in_roi:
                                hole_center_x = hole["x"] + hole["width"]/2
                                hole_center_y = hole["y"] + hole["height"]/2
                                hole_centers.append((hole_center_x, hole_center_y))
                            
                            # Größten Abstand zwischen zwei Löchern finden
                            max_distance = 0
                            for i1 in range(len(hole_centers)):
                                for i2 in range(i1+1, len(hole_centers)):
                                    x1, y1 = hole_centers[i1]
                                    x2, y2 = hole_centers[i2]
                                    distance = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
                                    max_distance = max(max_distance, distance)
                            
                            scatter_info = f"Ø {int(max_distance)} px"
                        
                        # Zeige auch ROIs ohne Löcher an, damit der Benutzer weiß,
                        # welche ROIs definiert wurden
                        data_rows.append([
                            f"{i+1}",
                            color_name,
                            str(len(holes_in_roi)),
                            scatter_info
                        ])
                    
                    # ROI-Tabelle erstellen
                    if data_rows and len(data_rows) > 1:
                        # Tabelle erstellen
                        table = Table(data_rows)
                        
                        # Farben direkt als RGB-Tuple definieren
                        gray_color = (0.7, 0.7, 0.7)
                        white_color = (1, 1, 1)
                        black_color = (0, 0, 0)
                        
                        table.setStyle(TableStyle([
                            ('BACKGROUND', (0, 0), (-1, 0), gray_color),
                            ('TEXTCOLOR', (0, 0), (-1, 0), white_color),
                            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                            ('BACKGROUND', (0, 1), (-1, -1), white_color),
                            ('GRID', (0, 0), (-1, -1), 1, black_color)
                        ]))
                        
                        # Tabelle zentrieren
                        table_width = 16*cm
                        # Präzisere Berechnung der Tabellenhöhe
                        table.wrapOn(c, table_width, height)
                        actual_table_height = len(data_rows) * 0.7*cm  # Größere Zeilenhöhe für bessere Lesbarkeit
                        
                        # Prüfen, ob die Tabelle auf die erste Seite passt
                        if content_y_start - actual_table_height - 6*cm < 3*cm:  # 6cm für Abstände und Formularfelder
                            # Nicht genug Platz - neue Seite beginnen
                            c.showPage()
                            # Seitentitel
                            c.setFont("Helvetica-Bold", 16)
                            c.drawString(2*cm, height - 2*cm, "E-Spektiv Hole - Schießbericht (Fortsetzung)")
                            
                            # Datum
                            c.setFont("Helvetica", 12)
                            c.drawString(2*cm, height - 3*cm, f"Datum: {report_date}")
                            
                            # ROI-Überschrift auf neuer Seite
                            c.setFont("Helvetica-Bold", 12)
                            c.drawString(2*cm, height - 4*cm, "ROI-Informationen")
                            
                            # Tabelle auf neuer Seite zeichnen
                            table.drawOn(c, (width - table_width) / 2, height - 4.5*cm - actual_table_height)
                            
                            # Freien Platz unter der Tabelle berechnen
                            content_bottom = height - 4.5*cm - actual_table_height - 1.5*cm
                            
                            # Seitennummer anpassen
                            total_pages = 2
                            page_number = 2
                            
                            # Auf der ersten Seite die Seitenzahl aktualisieren
                            c.saveState()
                            c.setFont("Helvetica", 8)
                            c.drawString(width - 4*cm, 1*cm, f"Seite 1/{total_pages}")
                            c.restoreState()
                        else:
                            # Tabelle auf erster Seite zeichnen
                            table.drawOn(c, (width - table_width) / 2, content_y_start - actual_table_height - 0.5*cm)
                            
                            # Freien Platz unter der Tabelle berechnen
                            content_bottom = content_y_start - actual_table_height - 1.5*cm
                            
                            # Seitennummer
                            total_pages = 1
                            page_number = 1
                    else:
                        # Keine ROI-Tabelle, aber trotzdem Platz reservieren
                        content_bottom = content_y_start - 1.5*cm
                        total_pages = 1
                        page_number = 1
                else:
                    # Keine ROIs definiert
                    content_bottom = content_y_start - 1.5*cm
                    total_pages = 1
                    page_number = 1
                
                # Freier Bereich für Eintragungen - unter der Tabelle/ROI-Bereich
                # Verwende die zuvor berechnete content_bottom-Position oder fallback auf einen festen Wert
                y_pos_form = locals().get('content_bottom', 10*cm)
                
                # Prüfen, ob noch genügend Platz auf der aktuellen Seite für die Formularfelder ist
                min_required_space = 6*cm  # Minimaler Platz für Formularfelder
                
                # Wenn bereits eine zweite Seite durch die Tabelle erzeugt wurde, überspringen wir diesen Teil
                # Die page_number wurde bereits in der Tabellenerstellung gesetzt
                if 'page_number' not in locals():
                    # Wir sind noch auf der ersten Seite
                    if y_pos_form < min_required_space + 3*cm:  # Abstand zur Fußzeile
                        c.showPage()  # Neue Seite beginnen
                        # Seitennummer erhöhen
                        page_number = 2
                        # Seitennummerierung anpassen
                        total_pages = 2
                        # Auf der ersten Seite die Seitenzahl aktualisieren
                        c.saveState()
                        c.setFont("Helvetica", 8)
                        c.drawString(width - 4*cm, 1*cm, f"Seite 1/{total_pages}")
                        c.restoreState()
                        
                        # Neuen Titel für die zweite Seite
                        c.setFont("Helvetica-Bold", 16)
                        c.drawString(2*cm, height - 2*cm, "E-Spektiv Hole - Schießbericht (Fortsetzung)")
                        
                        c.setFont("Helvetica", 12)
                        c.drawString(2*cm, height - 3*cm, f"Datum: {report_date}")
                        
                        # Position für Eintragungen auf der neuen Seite
                        y_pos_form = height - 4*cm
                    else:
                        page_number = 1
                        total_pages = 1
                
                c.setFont("Helvetica-Bold", 12)
                c.drawString(2*cm, y_pos_form, "Manuelle Eintragungen:")
                
                # Formularfelder für Eintragungen
                y_pos_form -= 1*cm
                c.setFont("Helvetica", 10)
                
                # Entfernung
                c.drawString(2.5*cm, y_pos_form, "Entfernung: ___________________ m")
                y_pos_form -= 0.8*cm
                
                # Streukreis in mm
                c.drawString(2.5*cm, y_pos_form, "Streukreis: ___________________ mm")
                y_pos_form -= 0.8*cm
                
                # MOA-Wert
                c.drawString(2.5*cm, y_pos_form, "MOA-Wert: ___________________")
                y_pos_form -= 0.8*cm
                
                # Bemerkungen
                c.drawString(2.5*cm, y_pos_form, "Bemerkungen: _________________________________________________________________")
                y_pos_form -= 1.5*cm
                
                # Unterschrift
                c.drawString(2.5*cm, y_pos_form, "Datum: ________________     Unterschrift: ________________________________")
                    
                # Fußzeile
                c.setFont("Helvetica", 8)
                c.drawString(2*cm, 1*cm, "Erstellt mit E-Spektiv Hole System")
                c.drawString(width - 4*cm, 1*cm, f"Seite {page_number}/{total_pages}")
                    
                # PDF abschließen
                c.save()
                
                # Temporäres Screenshot-Bild löschen, da es bereits im PDF enthalten ist
                os.remove(screenshot_path)
                
                # URL zum Herunterladen zurückgeben
                pdf_url = f"/temp/{report_filename}"
                return {"success": True, "pdf_url": pdf_url}
                
        except Exception as e:
            print(f"Fehler beim Erstellen des PDF-Berichts: {e}")
            return {"success": False, "error": str(e)}