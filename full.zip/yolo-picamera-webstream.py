#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import threading
import base64
from flask import Flask, Response, render_template, request, send_from_directory, jsonify

# Flask-App initialisieren
app = Flask(__name__)
from pathlib import Path
import io
import os
import datetime
import json
import pickle
import glob
import time
import cv2
import numpy as np
from pdf_report_generator import PDFReportGenerator
from version import VERSION, BUILD, RELEASE_DATE, get_version_string

# Pfad zur Konfigurationsdatei
CONFIG_PATH = "config/settings.json"

# Standard-Konfiguration (wird verwendet, wenn keine Konfigurationsdatei gefunden wird)
DEFAULT_CONFIG = {
    "camera": {
        "resolution": "1080p",
        "fps": 10,
        "confidenceThreshold": 0.4
    },
    "stream": {
        "jpegQuality": 70,
        "grayscale": False,
        "sharpness": 5
    },
    "visualization": {
        "displayScatterCircle": False,
        "scatterCircleColor": [255, 0, 0],  # BGR (Blau)
        "scatterCircleThickness": 2,
        "roiBorderThickness": 2,
        "holeMarkerThickness": 2,
        "roiDarkeningLevel": 50,  # Verdunklungsstärke für Bereiche außerhalb der ROI (0-100%)
        "holeColor": [0, 255, 0],  # BGR (Grün)
        "lastHoleColor": [0, 0, 255],  # BGR (Rot)
        "blinkLastHole": True,  # Blinken des letzten Lochs (ein/aus)
        "blinkRate": 500  # Blinkrate in Millisekunden
    },
    "interface": {
        "darkMode": True,
        "showTimestamp": True,
        "showCoordinates": False
    },
    "perspective": {
        "enabled": False,
        "points": [],
        "matrix": []
    }
}

# Konfiguration laden
def load_config():
    """Konfiguration aus der JSON-Datei laden"""
    try:
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, 'r') as f:
                config = json.load(f)
                print(f"Konfiguration aus {CONFIG_PATH} geladen")
                
                # Sicherstellen, dass der Perspective-Bereich korrekt initialisiert ist
                if 'perspective' not in config:
                    config['perspective'] = DEFAULT_CONFIG['perspective']
                    print("Perspektivkorrektur-Konfiguration fehlt, wird aus Standardwerten initialisiert")
                
                # Wenn perspective.points ein leeres Array ist, NICHT automatisch mit Standardwerten füllen
                # Die Punkte sollen nur durch explizite Kalibrierung gesetzt werden
                
                return config
        else:
            # Wenn keine Konfigurationsdatei existiert, Standard-Konfiguration speichern
            save_config(DEFAULT_CONFIG)
            print(f"Keine Konfigurationsdatei gefunden. Standard-Konfiguration in {CONFIG_PATH} gespeichert")
            return DEFAULT_CONFIG
    except Exception as e:
        print(f"Fehler beim Laden der Konfiguration: {e}")
        return DEFAULT_CONFIG

# Konfiguration speichern
def save_config(config):
    """Konfiguration in die JSON-Datei speichern"""
    try:
        # Sicherstellen, dass das Verzeichnis existiert
        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
        
        with open(CONFIG_PATH, 'w') as f:
            json.dump(config, f, indent=2)
            print(f"Konfiguration in {CONFIG_PATH} gespeichert")
        return True
    except Exception as e:
        print(f"Fehler beim Speichern der Konfiguration: {e}")
        return False

# Konfiguration laden
config = load_config()

# Auflösung aus der Konfiguration extrahieren
resolution_map = {
    "720p": (1280, 720),
    "1080p": (1920, 1080)
}
resolution = config["camera"]["resolution"]
IMG_WIDTH, IMG_HEIGHT = resolution_map.get(resolution, (1280, 720))

# Andere Variablen aus der Konfiguration setzen
MODEL_PATH = "bullet-hole_ncnn_model"  # Pfad zum YOLOv11-Modell
CONFIDENCE_THRESHOLD = config["camera"]["confidenceThreshold"]
FPS = config["camera"]["fps"]

# Stream-Konfiguration
STREAM_SCALE_FACTOR = 1.0  # Konstant für jetzt
STREAM_JPEG_QUALITY = config["stream"]["jpegQuality"]
STREAM_FPS_LIMIT = 5  # Konstant für jetzt
STREAM_GRAYSCALE = config["stream"]["grayscale"]

# Visualisierungs-Konfiguration
DISPLAY_SCATTER_CIRCLE = config["visualization"]["displayScatterCircle"]
SCATTER_CIRCLE_COLOR = tuple(config["visualization"]["scatterCircleColor"])  # BGR-Format
SCATTER_CIRCLE_THICKNESS = config["visualization"]["scatterCircleThickness"]
ROI_BORDER_THICKNESS = config["visualization"].get("roiBorderThickness", 2)  # Standardwert 2 wenn nicht definiert
HOLE_MARKER_THICKNESS = config["visualization"].get("holeMarkerThickness", 2)  # Standardwert 2 wenn nicht definiert
ROI_DARKENING_LEVEL = config["visualization"].get("roiDarkeningLevel", 50)  # Standardwert 50% wenn nicht definiert
HOLE_COLOR = tuple(config["visualization"]["holeColor"])  # BGR-Format
LAST_HOLE_COLOR = tuple(config["visualization"]["lastHoleColor"])  # BGR-Format
SHOW_ONLY_LAST_HOLE = config["visualization"].get("showOnlyLastHole", False)  # Standardmäßig alle Löcher anzeigen

# Interface-Konfiguration
DARK_MODE = config["interface"]["darkMode"]
SHOW_TIMESTAMP = config["interface"]["showTimestamp"]
SHOW_COORDINATES = config["interface"]["showCoordinates"]

# Globale Regions of Interest (ROIs) - anfangs leer
rois = []
roi_lock = threading.Lock()

# Globale Variable für erkannte Löcher
detected_holes = []
detected_holes_lock = threading.Lock()

# Globale Variablen für Perspektivkorrektur
PERSPECTIVE_ENABLED = config["perspective"]["enabled"]
perspective_points = config["perspective"]["points"]
perspective_matrix = None

# Globale Variablen für das neueste Einschussloch
newest_hole_time = 0  # Zeitstempel des neuesten Einschusslochs
newest_hole_data = None  # Daten des neuesten Einschusslochs (zum permanenten Anzeigen)

# Perspektivmatrix initialisieren, wenn Punkte in der Konfiguration vorhanden sind
if perspective_points and len(perspective_points) == 4:
    # Nicht automatisch Standardwerte erstellen - nur vorhandene Konfiguration verwenden
    src_points = np.array(perspective_points, dtype=np.float32)
    # Zielkoordinaten (rechteckig)
    dst_width = 1000  # Feste Breite für die entzerrte Ansicht
    dst_height = 1000  # Feste Höhe für die entzerrte Ansicht
    dst_points = np.array([
        [0, 0],
        [dst_width, 0],
        [dst_width, dst_height],
        [0, dst_height]
    ], dtype=np.float32)
    perspective_matrix = cv2.getPerspectiveTransform(src_points, dst_points)
    
    # Matrix in Konfiguration speichern (falls nicht bereits vorhanden)
    if 'matrix' not in config['perspective'] or not config['perspective']['matrix']:
        config['perspective']['matrix'] = perspective_matrix.tolist()
        save_config(config)
        print("Perspektivkorrektur-Matrix in Konfiguration gespeichert")

perspective_lock = threading.Lock()


# Initialisieren des Flask-Servers
app = Flask(__name__)

# Erstellen eines globalen Frame-Buffers
frame_buffer = None
frame_lock = threading.Lock()

# Globaler Status für die Objekterkennung (anfangs ausgeschaltet)
detection_enabled = False
detection_status_lock = threading.Lock()

# Globaler Objektzähler
object_count = 0
object_count_lock = threading.Lock()

# Sicherstellen, dass der static-Ordner und Favicon existieren
def setup_static():
    # Statisches Verzeichnis erstellen, falls es nicht existiert
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
    if not os.path.exists(static_dir):
        os.makedirs(static_dir)
        
    # Favicon als Datei speichern, falls es nicht existiert
    favicon_path = os.path.join(static_dir, 'favicon.svg')
    if not os.path.exists(favicon_path):
        with open(favicon_path, 'w') as f:
            f.write('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <!-- Hintergrund -->
  <rect width="64" height="64" rx="12" fill="#3B82F6"/>
  
  <!-- Kamerablende (stilisiert) -->
  <circle cx="32" cy="32" r="20" fill="#1E3A8A" stroke="#FFFFFF" stroke-width="2"/>
  
  <!-- Kameralinse -->
  <circle cx="32" cy="32" r="12" fill="#FFFFFF" opacity="0.9"/>
  
  <!-- Objekterkennungsmarkierung (stilisiert) -->
  <rect x="20" y="20" width="24" height="24" rx="2" stroke="#F59E0B" stroke-width="3" fill="none"/>
  
  <!-- "Y" für YOLO -->
  <text x="32" y="36" text-anchor="middle" font-family="Arial" font-weight="bold" font-size="12" fill="#F59E0B">Y</text>
</svg>''')
    
    return static_dir

# Alt: Die ObjectDetection-Klasse wurde in die Datei object_detection.py ausgelagert.
# Dieser Kommentar dient als Hinweis auf die ausgelagerte Implementierung.

class ObjectDetection:
    """HINWEIS: Diese Klasse wurde in eine separate Datei ausgelagert.
    Die ursprüngliche Implementierung ist in object_detection.py zu finden."""
    def __init__(self, *args, **kwargs):
        # Diese Methode wird nicht mehr verwendet
        pass
    
    def _calculate_and_draw_scatter_circle(self, objects, frame, color=None, label=None):
        """Berechnet und zeichnet einen Streukreis für die gegebenen Objekte"""
        if color is None:
            color = SCATTER_CIRCLE_COLOR
        
        # Nur fortfahren, wenn mindestens 2 Objekte vorhanden sind
        if len(objects) < 2:
            return None
        
        # Struktur für alle Einschusslöcher mit ihren Boxen
        hole_boxes = []
        hole_centers = []
        for result in objects:
            x1, y1, x2, y2 = map(int, result[:4])
            # Jedes Loch als Box und Mittelpunkt speichern
            hole_boxes.append((x1, y1, x2, y2))
            hole_center_x = (x1 + x2) / 2
            hole_center_y = (y1 + y2) / 2
            hole_centers.append((hole_center_x, hole_center_y))
        
        # Geometrischen Mittelpunkt für die Anzeige der Koordinaten berechnen
        center_x = sum(x for x, y in hole_centers) / len(hole_centers)
        center_y = sum(y for x, y in hole_centers) / len(hole_centers)
        
        # Größten Abstand zwischen den äußersten Kanten zweier Löcher finden (echter Streukreis)
        max_distance = 0
        max_hole1 = None
        max_hole2 = None
        max_edge1 = None
        max_edge2 = None
        
        # Alle Paare von Löchern vergleichen
        for i in range(len(hole_boxes)):
            for j in range(i+1, len(hole_boxes)):
                # Boxen der beiden Löcher
                box1 = hole_boxes[i]  # (x1, y1, x2, y2) des ersten Lochs
                box2 = hole_boxes[j]  # (x1, y1, x2, y2) des zweiten Lochs
                
                # Jetzt für alle 4 Ecken der Box 1 den maximalen Abstand zu allen 4 Ecken der Box 2 berechnen
                # Liste aller Ecken von Box 1
                corners1 = [
                    (box1[0], box1[1]),  # links oben
                    (box1[2], box1[1]),  # rechts oben
                    (box1[0], box1[3]),  # links unten
                    (box1[2], box1[3])   # rechts unten
                ]
                
                # Liste aller Ecken von Box 2
                corners2 = [
                    (box2[0], box2[1]),  # links oben
                    (box2[2], box2[1]),  # rechts oben
                    (box2[0], box2[3]),  # links unten
                    (box2[2], box2[3])   # rechts unten
                ]
                
                # Alle Ecken-Kombinationen prüfen
                for c1 in corners1:
                    for c2 in corners2:
                        x1, y1 = c1
                        x2, y2 = c2
                        distance = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
                        if distance > max_distance:
                            max_distance = distance
                            max_edge1 = c1
                            max_edge2 = c2
                            max_hole1 = hole_centers[i]
                            max_hole2 = hole_centers[j]
        
        # Mitte des Streukreises (genau zwischen den beiden äußersten Kanten)
        if max_edge1 and max_edge2:
            # Mittelpunkt zwischen den äußersten Kanten verwenden
            scatter_center_x = (max_edge1[0] + max_edge2[0]) / 2
            scatter_center_y = (max_edge1[1] + max_edge2[1]) / 2
            scatter_radius = max_distance / 2
            
            # Die Zentren der beiden Löcher mit dem maximalen Abstand
            hole1_center = max_hole1
            hole2_center = max_hole2
        else:
            scatter_center_x = center_x
            scatter_center_y = center_y
            scatter_radius = 0
            hole1_center = None
            hole2_center = None
        
        # Streukreis nur zeichnen, wenn in den Einstellungen aktiviert
        if DISPLAY_SCATTER_CIRCLE:
            # Streukreis zeichnen mit konfigurierbarer Farbe und Linienstärke
            cv2.circle(frame, (int(scatter_center_x), int(scatter_center_y)), 
                      int(scatter_radius), color, SCATTER_CIRCLE_THICKNESS)
            
            # Zentroid markieren (mit invertierten RGB-Werten für Kontrast)
            inverse_color = tuple(255 - c for c in color)
            cv2.circle(frame, (int(scatter_center_x), int(scatter_center_y)), 
                      5, inverse_color, -1)
                      
            # Die beiden entferntesten Punkte hervorheben
            if max_edge1 and max_edge2:
                # Linie zwischen den entferntesten Kanten zeichnen
                cv2.line(frame, 
                       (int(max_edge1[0]), int(max_edge1[1])),
                       (int(max_edge2[0]), int(max_edge2[1])),
                       color, 1, cv2.LINE_AA)
                       
                # Die entferntesten Kanten markieren
                cv2.circle(frame, (int(max_edge1[0]), int(max_edge1[1])), 3, color, -1)
                cv2.circle(frame, (int(max_edge2[0]), int(max_edge2[1])), 3, color, -1)
            
            # Label hinzufügen, wenn angegeben (nur ROI-Nummer ohne Abmaße)
            if label:
                cv2.putText(frame, label, 
                           (int(scatter_center_x) - 20, int(scatter_center_y) - 15), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
            # Koordinaten für diese spezifische ROI anzeigen, wenn aktiviert
            if SHOW_COORDINATES:
                coords_text = f"X={int(scatter_center_x)}, Y={int(scatter_center_y)}"
                cv2.putText(frame, coords_text, 
                           (int(scatter_center_x) - 60, int(scatter_center_y) + 20), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        
        return {
            "center_x": scatter_center_x,
            "center_y": scatter_center_y,
            "radius": scatter_radius,
            "distance": max_distance
        }

    # Verbesserte Methode für die Überprüfung, ob ein erkanntes Objekt innerhalb einer der ROIs liegt
    def is_in_roi(self, box):
        """Prüft, ob eine Box innerhalb einer der ROIs liegt"""
        global rois, PERSPECTIVE_ENABLED, perspective_matrix
        
        with roi_lock:
            # Wenn keine ROIs definiert sind, ist alles innerhalb
            if not rois:
                return True
                
            # Koordinaten der Box
            x1, y1, x2, y2 = box[:4]
            
            # Box-Mittelpunkt berechnen
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            
            # Prüfen, ob der Mittelpunkt innerhalb einer der ROIs liegt
            for roi in rois:
                roi_x = max(0, roi["x"])
                roi_y = max(0, roi["y"])
                roi_width = max(1, roi["width"])
                roi_height = max(1, roi["height"])
                
                if (center_x >= roi_x and 
                    center_x <= roi_x + roi_width and
                    center_y >= roi_y and
                    center_y <= roi_y + roi_height):
                    return True
            
            # Wenn der Punkt in keiner ROI liegt
            return False

    def detect_objects(self, frame):
        global detection_enabled, object_count, rois, PERSPECTIVE_ENABLED, perspective_matrix, ROI_DARKENING_LEVEL
        global newest_hole_time, newest_hole_data
    
        # Annotiertes Bild erstellen
        annotated_frame = frame.copy()
        
        # Letzter Treffer persistieren: Zeichne das zuletzt erkannte Loch, falls vorhanden
        # Nur zeichnen, wenn Erkennung aktiv ist und Daten vorhanden sind
        if newest_hole_data and SHOW_ONLY_LAST_HOLE and detection_enabled:
            # Das letzte Loch mit Kreis und Kreuz zeichnen
            if 'center_x' in newest_hole_data:
                # Neue Darstellung mit Kreis und Kreuz
                center_x = newest_hole_data['center_x']
                center_y = newest_hole_data['center_y']
                radius = newest_hole_data['radius']
                
                # Kreis zeichnen
                cv2.circle(annotated_frame, (center_x, center_y), radius, LAST_HOLE_COLOR, HOLE_MARKER_THICKNESS + 1)
                
                # Kreuz zeichnen (horizontale Linie)
                cv2.line(annotated_frame, 
                        (center_x - radius, center_y), 
                        (center_x + radius, center_y), 
                        LAST_HOLE_COLOR, max(1, (HOLE_MARKER_THICKNESS + 1) // 2))
                
                # Kreuz zeichnen (vertikale Linie)
                cv2.line(annotated_frame, 
                        (center_x, center_y - radius), 
                        (center_x, center_y + radius), 
                        LAST_HOLE_COLOR, max(1, (HOLE_MARKER_THICKNESS + 1) // 2))
            else:
                # Fallback für alte Daten ohne center_x/center_y
                x1, y1, x2, y2 = newest_hole_data['x1'], newest_hole_data['y1'], newest_hole_data['x2'], newest_hole_data['y2']
                cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), LAST_HOLE_COLOR, HOLE_MARKER_THICKNESS + 1)
            
        # ROIs darstellen, wenn vorhanden
        with roi_lock:
            if rois:
                # Transparente Überlagerung für Bereiche außerhalb der ROIs erstellen
                overlay = annotated_frame.copy()
                
                # Maske für den Bereich außerhalb der ROIs
                mask = np.ones(annotated_frame.shape[:2], dtype=np.uint8) * 255
                
                # Alle ROIs in der Maske berücksichtigen
                for roi in rois:
                    # Sicherstellen, dass die ROI-Koordinaten gültige Werte haben
                    x = max(0, min(roi["x"], annotated_frame.shape[1] - 1))
                    y = max(0, min(roi["y"], annotated_frame.shape[0] - 1))
                    width = max(1, min(roi["width"], annotated_frame.shape[1] - x))
                    height = max(1, min(roi["height"], annotated_frame.shape[0] - y))
                    
                    # Die ROI in der Maske ausschneiden
                    cv2.rectangle(mask, (x, y), (x + width, y + height), 0, -1)
                
                # Verdunklungsstärke berechnen (0 bis 100%)
                darkening_factor = ROI_DARKENING_LEVEL / 100.0
                # Bei 0% keine Verdunklung, bei 100% vollständig schwarz
                if darkening_factor > 0:
                    # Verdunkeln der Bereiche außerhalb aller ROIs basierend auf dem Faktor
                    # Je höher der Faktor, desto dunkler
                    darkening_divisor = max(1, 2 * darkening_factor)  # Bei 50% wird durch 2 geteilt (wie zuvor)
                    
                    # Pixel in Maske verdunkeln
                    overlay[mask == 255] = (overlay[mask == 255] * (1 - darkening_factor)).astype(np.uint8)
                    
                    # Gewichtete Überlagerung anwenden
                    alpha = 0.5  # Mischfaktor
                    cv2.addWeighted(overlay, alpha, annotated_frame, 1.0 - alpha, 0, annotated_frame)
                
                # ROI-Rahmen zeichnen für jede ROI
                for i, roi in enumerate(rois):
                    x = max(0, min(roi["x"], annotated_frame.shape[1] - 1))
                    y = max(0, min(roi["y"], annotated_frame.shape[0] - 1))
                    width = max(1, min(roi["width"], annotated_frame.shape[1] - x))
                    height = max(1, min(roi["height"], annotated_frame.shape[0] - y))
                    
                    # ROI-Rahmen mit unterschiedlichen Farben für bessere Unterscheidung
                    # Farbzyklus: Gelb, Orange, Cyan
                    colors = [(0, 255, 255), (0, 165, 255), (255, 255, 0)]
                    color = colors[i % len(colors)]
                    
                    cv2.rectangle(annotated_frame, (x, y), (x + width, y + height), color, ROI_BORDER_THICKNESS)
                    
                    # ROI-Nummer in der Ecke des Auswahlbereichs anzeigen
                    cv2.putText(annotated_frame, f"ROI {i+1}", (x + 5, y + 20), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        
        # Objektzähler auf 0 setzen, wenn die Erkennung deaktiviert ist
        if not detection_enabled:
            with object_count_lock:
                object_count = 0
        
        # Objekterkennung nur durchführen, wenn sie aktiviert ist
        elif detection_enabled:
            # Objekte im Frame erkennen
            results = self.model(frame, conf=CONFIDENCE_THRESHOLD)[0]
            
            # Zähler für erkannte Objekte zurücksetzen
            current_count = 0
            
            # Erkannte Objekte filtern und visualisieren
            detected_objects = results.boxes.data.tolist()
            
            # Wenn keine ROIs definiert sind, alle Objekte betrachten
            if not rois:
                filtered_objects = []
                for result in detected_objects:
                    if self.is_in_roi(result):  # is_in_roi gibt in diesem Fall immer True zurück
                        filtered_objects.append(result)
                
                # Streukreis für alle erkannten Objekte berechnen
                self._calculate_and_draw_scatter_circle(filtered_objects, annotated_frame)
            else:
                # ROI-spezifische Filterung und Streukreisberechnung
                filtered_objects = []  # Gesamtliste für alle gefilterten Objekte
                
                # Für jede definierte ROI einen eigenen Streukreis berechnen
                for roi_index, roi in enumerate(rois):
                    # Objekte filtern, die in dieser spezifischen ROI liegen
                    roi_objects = []
                    for result in detected_objects:
                        # Box-Koordinaten extrahieren
                        x1, y1, x2, y2 = result[:4]
                        
                        # Mittelpunkt der Box berechnen
                        center_x = (x1 + x2) / 2
                        center_y = (y1 + y2) / 2
                        
                        # Wir transformieren die Koordinaten nicht mehr, da wir das Bild bereits am Anfang transformiert haben
                        
                        # Prüfen, ob der Mittelpunkt in dieser ROI liegt
                        roi_x = max(0, roi["x"])
                        roi_y = max(0, roi["y"])
                        roi_width = max(1, roi["width"])
                        roi_height = max(1, roi["height"])
                        
                        if (center_x >= roi_x and 
                            center_x <= roi_x + roi_width and
                            center_y >= roi_y and
                            center_y <= roi_y + roi_height):
                            roi_objects.append(result)
                            filtered_objects.append(result)  # Auch zur Gesamtliste hinzufügen
                    
                    # Farbe für diese ROI aus dem Farbzyklus holen
                    colors = [(0, 255, 255), (0, 165, 255), (255, 255, 0), (0, 255, 0), (255, 0, 255)]
                    roi_color = colors[roi_index % len(colors)]
                    
                    # Streukreis für diese ROI berechnen und zeichnen
                    self._calculate_and_draw_scatter_circle(
                        roi_objects, 
                        annotated_frame, 
                        color=roi_color,
                        label=f"ROI {roi_index+1}"
                    )
            
            # Koordinaten des gesamten Zentrums anzeigen, wenn aktiviert
            if SHOW_COORDINATES and filtered_objects:
                # Mittelpunkte aller Einschusslöcher sammeln
                hole_centers = []
                for result in filtered_objects:
                    x1, y1, x2, y2 = map(int, result[:4])
                    hole_center_x = (x1 + x2) / 2
                    hole_center_y = (y1 + y2) / 2
                    hole_centers.append((hole_center_x, hole_center_y))
                
                # Geometrischen Mittelpunkt berechnen
                if hole_centers:
                    center_x = sum(x for x, y in hole_centers) / len(hole_centers)
                    center_y = sum(y for x, y in hole_centers) / len(hole_centers)
                    
                    coordinates_text = f"Gesamt-Zentrum: X={int(center_x)}, Y={int(center_y)}"
                    cv2.putText(annotated_frame, coordinates_text, 
                              (10, annotated_frame.shape[0] - 40), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            # Erkannte und gefilterte Objekte visualisieren
            for i, result in enumerate(filtered_objects):
                x1, y1, x2, y2, confidence, class_id = result
                
                # Zu Integer konvertieren für OpenCV
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                
                                # Wir sollten das neueste Objekt basierend auf der Erkennung markieren, nicht 
                # basierend auf der Position in der Liste
                is_newest_hole = False
                
                # Hole-Daten für dieses Objekt
                hole_data = create_hole_object((x1, y1, x2, y2), confidence)
                
                # Bei der ersten Erkennung (Liste ist noch leer), ist dies das neueste Objekt
                if not detected_holes:
                    is_newest_hole = True
                else:
                    # Prüfen, ob dies ein neues Objekt ist, das noch nicht in detected_holes ist
                    is_new_hole = True
                    for existing_hole in detected_holes:
                        # Prüfen auf Überlappung mit einem bestehenden Loch
                        existing_center_x = existing_hole["x"] + existing_hole["width"] / 2
                        existing_center_y = existing_hole["y"] + existing_hole["height"] / 2
                        
                        current_center_x = hole_data["x"] + hole_data["width"] / 2
                        current_center_y = hole_data["y"] + hole_data["height"] / 2
                        
                        # Wenn die Zentren nahe beieinander liegen (z.B. weniger als 15 Pixel), ist es das gleiche Loch
                        if (abs(existing_center_x - current_center_x) < 15 and 
                            abs(existing_center_y - current_center_y) < 15):
                            is_new_hole = False
                            break
                    
                    is_newest_hole = is_new_hole
                
                # Neues Loch erkannt?
                if is_newest_hole and detection_enabled:  # Nur aktualisieren wenn Erkennung aktiv
                    # Wenn dieses Objekt neu ist, aktualisiere newest_hole_time und -data
                    with detected_holes_lock:
                        newest_hole_time = time.time()
                        # Speichere das aktuelle Loch als neuestes Loch
                        # Mittelpunkt und Radius berechnen
                        center_x = (x1 + x2) // 2
                        center_y = (y1 + y2) // 2
                        radius = max((x2 - x1) // 2, (y2 - y1) // 2)
                        
                        newest_hole_data = {
                            'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 
                            'center_x': center_x, 'center_y': center_y, 'radius': radius,
                            'time': newest_hole_time
                        }
                    
                    # Immer die konfigurierte Farbe für das neueste Loch verwenden (rot)
                    color = LAST_HOLE_COLOR
                    line_thickness = HOLE_MARKER_THICKNESS + 1  # Etwas dicker für das neueste Loch
                    
                    # Kreis mit Kreuz für das neueste Loch zeichnen
                    center_x = (x1 + x2) // 2
                    center_y = (y1 + y2) // 2
                    radius = max((x2 - x1) // 2, (y2 - y1) // 2)
                    
                    # Kreis zeichnen
                    cv2.circle(annotated_frame, (center_x, center_y), radius, color, line_thickness)
                    
                    # Kreuz zeichnen (horizontale Linie)
                    cv2.line(annotated_frame, 
                            (center_x - radius, center_y), 
                            (center_x + radius, center_y), 
                            color, line_thickness // 2)
                    
                    # Kreuz zeichnen (vertikale Linie)
                    cv2.line(annotated_frame, 
                            (center_x, center_y - radius), 
                            (center_x, center_y + radius), 
                            color, line_thickness // 2)
                elif not SHOW_ONLY_LAST_HOLE and detection_enabled:
                    # Ältere Löcher nur anzeigen, wenn die Option nicht aktiviert ist
                    # und die Erkennung eingeschaltet ist
                    color = HOLE_COLOR
                    line_thickness = HOLE_MARKER_THICKNESS
                    
                    # Für ältere Löcher auch Kreis mit Kreuz verwenden
                    center_x = (x1 + x2) // 2
                    center_y = (y1 + y2) // 2
                    radius = max((x2 - x1) // 2, (y2 - y1) // 2)
                    
                    # Kreis zeichnen
                    cv2.circle(annotated_frame, (center_x, center_y), radius, color, line_thickness)
                    
                    # Kreuz zeichnen (horizontale Linie)
                    cv2.line(annotated_frame, 
                           (center_x - radius, center_y), 
                           (center_x + radius, center_y), 
                           color, line_thickness // 2)
                    
                    # Kreuz zeichnen (vertikale Linie)
                    cv2.line(annotated_frame, 
                           (center_x, center_y - radius), 
                           (center_x, center_y + radius), 
                           color, line_thickness // 2)
                
                # Objekte zählen 
                current_count += 1
            
            # Globalen Objektzähler aktualisieren
            with object_count_lock:
                object_count = current_count
        
        # Status-Texte vorbereiten
        status_text = "Erkennung: EIN" if detection_enabled else "Erkennung: AUS"
        display_text = f"Anzeige: {('Nur letzter Treffer' if SHOW_ONLY_LAST_HOLE else 'Alle Treffer')}"
        roi_text = f"ROI: {len(rois)} AKTIV" if rois else "ROI: INAKTIV"
        
        # Objektzähler - immer vorbereiten, auch wenn nicht aktiv
        with object_count_lock:
            count_label = f"Objekte: {object_count if detection_enabled else 0}"
        
        # Textgrößen berechnen
        count_size = cv2.getTextSize(count_label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
        status_size = cv2.getTextSize(status_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
        display_size = cv2.getTextSize(display_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
        roi_size = cv2.getTextSize(roi_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
        
        # Maximale Breite für das Rechteck ermitteln
        max_width = max(count_size[0], status_size[0], display_size[0], roi_size[0]) + 20
        rect_height = count_size[1] + status_size[1] + display_size[1] + roi_size[1] + 60  # Höhe für vier Zeilen plus Abstand
        
        # Halbtransparentes Hintergrundrechteck erstellen
        overlay = annotated_frame.copy()
        cv2.rectangle(overlay, (10, 10), (10 + max_width, 10 + rect_height), (0, 0, 0), -1)
        
        # Transparenz anwenden (0.6 bedeutet 60% Deckkraft)
        alpha = 0.6
        cv2.addWeighted(overlay, alpha, annotated_frame, 1 - alpha, 0, annotated_frame)
        
        # Objektzähler einzeichnen (immer anzeigen)
        cv2.putText(annotated_frame, count_label, (15, 15 + count_size[1]), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Status einzeichnen
        status_color = (0, 255, 0) if detection_enabled else (0, 0, 255)
        cv2.putText(annotated_frame, status_text, (15, 15 + count_size[1] + 15 + status_size[1]), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, status_color, 2)
        
        # Trefferanzeige-Status einzeichnen (direkt unter dem Erkennungsstatus)
        display_color = (0, 255, 128) if SHOW_ONLY_LAST_HOLE else (128, 255, 0)
        cv2.putText(annotated_frame, display_text, 
                   (15, 15 + count_size[1] + 15 + status_size[1] + 15 + display_size[1]), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, display_color, 2)
        
        # ROI-Status einzeichnen
        roi_color = (0, 255, 255) if rois else (128, 128, 128)
        cv2.putText(annotated_frame, roi_text, 
                   (15, 15 + count_size[1] + 15 + status_size[1] + 15 + display_size[1] + 15 + roi_size[1]), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, roi_color, 2)
        
        # Nach der Verarbeitung der erkannten Objekte:
        if detection_enabled:
            # Hole-Daten aktualisieren, wenn Erkennung aktiviert ist
            with detected_holes_lock:
                # Liste leeren, um sie neu zu füllen
                detected_holes.clear()
                
                # Allgemeine Liste aller erkannten Löcher
                all_holes = []
                
                # Für jedes erkannte und gefilterte Objekt
                for result in filtered_objects:
                    x1, y1, x2, y2, confidence, class_id = result
                    # Loch-Objekt erstellen
                    hole = create_hole_object((x1, y1, x2, y2), confidence)
                    
                    # Zur allgemeinen Liste hinzufügen
                    all_holes.append(hole)
                
                # Wenn ROIs definiert sind, jedes Loch der entsprechenden ROI zuordnen
                if rois:
                    # ROIs für alle Löcher definieren
                    
                    # Behandlung für Perspektivmodus - wenn in Perspektivkorrektur ROIs verwendet werden
                    if PERSPECTIVE_ENABLED and perspective_matrix is not None:
                        # Im Perspektivmodus kann es zu Verschiebungen kommen, daher fügen wir
                        # Löcher direkt hinzu und markieren sie mit ROI-Index bei Bedarf
                        for hole in all_holes:
                            # Mittelpunkt des Lochs berechnen
                            hole_center_x = hole["x"] + hole["width"] / 2
                            hole_center_y = hole["y"] + hole["height"] / 2
                            
                            # Für jede ROI prüfen, ob der Mittelpunkt darin liegt
                            for roi_index, roi in enumerate(rois):
                                roi_x = max(0, roi["x"])
                                roi_y = max(0, roi["y"])
                                roi_width = max(1, roi["width"])
                                roi_height = max(1, roi["height"])
                                
                                if (hole_center_x >= roi_x and 
                                    hole_center_x <= roi_x + roi_width and
                                    hole_center_y >= roi_y and
                                    hole_center_y <= roi_y + roi_height):
                                    # ROI-Information zum Loch hinzufügen
                                    hole_with_roi = hole.copy()
                                    # ROI-Index als Integer speichern, nicht als String
                                    hole_with_roi["roi_index"] = int(roi_index)
                                    hole_with_roi["roi_id"] = roi.get("id", 0)
                                    detected_holes.append(hole_with_roi)
                                    break
                            else:
                                # Wenn das Loch in keiner ROI liegt, fügen wir es ohne ROI-Info hinzu
                                # im Perspektivmodus - wichtig für PDF-Berichte
                                detected_holes.append(hole)
                                
                    else:
                        # Standard-Logik für Nicht-Perspektiv-Modus
                        for roi_index, roi in enumerate(rois):
                            roi_holes = []
                            # Löcher für diese ROI sammeln
                            for hole in all_holes:
                                # Mittelpunkt des Lochs berechnen
                                hole_center_x = hole["x"] + hole["width"] / 2
                                hole_center_y = hole["y"] + hole["height"] / 2
                                
                                # Prüfen, ob der Mittelpunkt in dieser ROI liegt
                                roi_x = max(0, roi["x"])
                                roi_y = max(0, roi["y"])
                                roi_width = max(1, roi["width"])
                                roi_height = max(1, roi["height"])
                                
                                if (hole_center_x >= roi_x and 
                                    hole_center_x <= roi_x + roi_width and
                                    hole_center_y >= roi_y and
                                    hole_center_y <= roi_y + roi_height):
                                    # ROI-Information zum Loch hinzufügen
                                    hole_with_roi = hole.copy()
                                    # ROI-Index als Integer speichern, damit er später beim Vergleich korrekt funktioniert
                                    hole_with_roi["roi_index"] = int(roi_index)
                                    hole_with_roi["roi_id"] = roi.get("id", 0)
                                    roi_holes.append(hole_with_roi)
                            
                            # Löcher für diese ROI zu detected_holes hinzufügen
                            detected_holes.extend(roi_holes)
                    
                    # Löcher erfolgreich verarbeitet
                else:
                    # Wenn keine ROIs definiert sind, alle Löcher ohne ROI-Information hinzufügen
                    detected_holes.extend(all_holes)
        
        
        
        return annotated_frame
    
    def _get_color(self, class_id):
        # Eindeutige Farbe für jede Klasse generieren
        np.random.seed(class_id)
        color = tuple(map(int, np.random.randint(0, 255, 3)))
        return color
    
    def capture_frames(self):
        global frame_buffer
        
        while True:
            try:
                # Frame von der Kamera abrufen
                frame = self.camera.capture_array()
                
                # Perspektivkorrektur vor der Objekterkennung anwenden
                corrected_frame = frame.copy()
                if PERSPECTIVE_ENABLED and perspective_matrix is not None and len(perspective_points) == 4:
                    try:
                        with perspective_lock:
                            # Bild transformieren
                            dst_width = 1000  # Gleiche Werte wie bei Erstellung der Matrix
                            dst_height = 1000
                            corrected_frame = cv2.warpPerspective(corrected_frame, perspective_matrix, 
                                                               (dst_width, dst_height))
                    except Exception as e:
                        print(f"Fehler bei der Perspektivkorrektur: {e}")
                        corrected_frame = frame.copy()  # Zurück zum Original bei Fehler
                else:
                    corrected_frame = frame.copy()
                
                # Objekte im korrigierten Frame erkennen
                processed_frame = self.detect_objects(corrected_frame)
                
                # Restliche Optimierungen anwenden
                optimized_frame = self.optimize_frame_for_streaming(processed_frame)
                
                # Verarbeiteten Frame im globalen Buffer speichern
                with frame_lock:
                    # JPEG-Qualität reduzieren für niedrigere Bandbreite
                    encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), STREAM_JPEG_QUALITY]
                    _, buffer = cv2.imencode('.jpg', optimized_frame, encode_params)
                    frame_buffer = buffer.tobytes()
                
            except Exception as e:
                print(f"Fehler bei der Bildverarbeitung: {e}")
                time.sleep(0.1)  # Kurze Pause bei Fehlern
    
    def optimize_frame_for_streaming(self, frame):
        """Optimiert den Frame für das Streaming mit niedrigerer Bandbreite"""
        global PERSPECTIVE_ENABLED, perspective_matrix, perspective_points, detection_enabled
        
        # Eine Kopie des Frames erstellen, damit die Originaldaten nicht verändert werden
        output_frame = frame.copy()
        
        # Die Kalibrierpunkte anzeigen, wenn sie vorhanden sind und Kalibrierungsmodus aktiv ist
        # Aber nur, wenn die Perspektivkorrektur nicht aktiv ist oder wir im Kalibrierungsmodus sind
        if not PERSPECTIVE_ENABLED and len(perspective_points) > 0:
            # Punkte anzeigen für Feedback während der Kalibrierung
            for i, point in enumerate(perspective_points):
                if len(point) == 2:  # Sicherstellen, dass es ein gültiger Punkt ist
                    x, y = int(point[0]), int(point[1])
                    # Farbauswahl nach Index
                    colors = [(0, 0, 255), (0, 255, 0), (255, 0, 0), (255, 255, 0)]
                    color = colors[i % len(colors)]
                    # Punkt auf dem Frame zeichnen
                    cv2.circle(output_frame, (x, y), 10, color, -1)
                    cv2.putText(output_frame, str(i+1), (x+10, y+10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
            
            # Linien zwischen den Punkten zeichnen, wenn mindestens 2 Punkte vorhanden sind
            if len(perspective_points) >= 2:
                for i in range(len(perspective_points)):
                    if i+1 < len(perspective_points):  # Verbinde mit dem nächsten Punkt
                        pt1 = (int(perspective_points[i][0]), int(perspective_points[i][1]))
                        pt2 = (int(perspective_points[i+1][0]), int(perspective_points[i+1][1]))
                        cv2.line(output_frame, pt1, pt2, (255, 255, 255), 2)
                
                # Verbinde letzten und ersten Punkt, wenn 4 Punkte vorhanden sind
                if len(perspective_points) == 4:
                    pt1 = (int(perspective_points[3][0]), int(perspective_points[3][1]))
                    pt2 = (int(perspective_points[0][0]), int(perspective_points[0][1]))
                    cv2.line(output_frame, pt1, pt2, (255, 255, 255), 2)
        
        # Frame-Größe reduzieren falls gewünscht
        if STREAM_SCALE_FACTOR != 1.0:
            new_width = int(output_frame.shape[1] * STREAM_SCALE_FACTOR)
            new_height = int(output_frame.shape[0] * STREAM_SCALE_FACTOR)
            output_frame = cv2.resize(output_frame, (new_width, new_height), interpolation=cv2.INTER_AREA)
        
        # In Graustufen konvertieren falls gewünscht
        if STREAM_GRAYSCALE and len(output_frame.shape) == 3:
            output_frame = cv2.cvtColor(output_frame, cv2.COLOR_BGR2GRAY)
        
        return output_frame

def generate_frames():
    global frame_buffer
    
    # Zeitlicher Abstand zwischen Frames (basierend auf STREAM_FPS_LIMIT)
    frame_interval = 1.0 / STREAM_FPS_LIMIT
    last_frame_time = 0
    
    while True:
        current_time = time.time()
        # Prüfen, ob es Zeit für einen neuen Frame ist (FPS-Begrenzung)
        if (current_time - last_frame_time) >= frame_interval and frame_buffer is not None:
            with frame_lock:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame_buffer + b'\r\n')
            last_frame_time = current_time
            
        # Kurze Pause, um CPU-Auslastung zu reduzieren
        time.sleep(0.01)

# Statischen Ordner konfigurieren
static_folder = setup_static()

# Hole-Objekt aus der Box-Erkennung erstellen
def create_hole_object(box, confidence):
    global PERSPECTIVE_ENABLED, perspective_matrix
    
    x1, y1, x2, y2 = box[:4]
    
    # Wenn Perspektivkorrektur aktiviert ist und Matrix vorhanden, Box transformieren
    if PERSPECTIVE_ENABLED and perspective_matrix is not None:
        try:
            with perspective_lock:
                # Alle vier Ecken der Box in einem Array sammeln
                points = np.array([
                    [[x1, y1]],  # links oben
                    [[x2, y1]],  # rechts oben
                    [[x2, y2]],  # rechts unten
                    [[x1, y2]]   # links unten
                ], dtype=np.float32)
                
                # Punkte transformieren
                transformed_points = cv2.perspectiveTransform(points, perspective_matrix)
                
                # Neue Bounding Box aus transformierten Punkten
                new_x1 = min(p[0][0] for p in transformed_points)
                new_y1 = min(p[0][1] for p in transformed_points)
                new_x2 = max(p[0][0] for p in transformed_points)
                new_y2 = max(p[0][1] for p in transformed_points)
                
                # Neue Koordinaten verwenden
                x1, y1, x2, y2 = new_x1, new_y1, new_x2, new_y2
                
                # Debugausgabe bei Bedarf
                # print(f"Perspektivkorrektur angewendet: Original: ({box[0]:.1f}, {box[1]:.1f}) -> ({box[2]:.1f}, {box[3]:.1f}), Korrigiert: ({x1:.1f}, {y1:.1f}) -> ({x2:.1f}, {y2:.1f})")
        except Exception as e:
            print(f"Fehler bei der Perspektivkorrektur: {e}")
    
    return {
        "x": int(x1),
        "y": int(y1),
        "width": int(x2 - x1),
        "height": int(y2 - y1),
        "confidence": float(confidence),
        "timestamp": datetime.datetime.now().isoformat(),
        "perspective_corrected": PERSPECTIVE_ENABLED and perspective_matrix is not None
    }



@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory(static_folder, path)

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(static_folder, 'favicon.svg')

@app.route('/static/js/<path:path>')
def send_js(path):
    """JavaScript-Dateien bereitstellen"""
    return send_from_directory(os.path.join(static_folder, 'js'), path)
    
@app.route('/version')
def version_info():
    """Gibt die Versionsinformationen des Systems zurück"""
    from version import get_version_info
    return jsonify(get_version_info())

@app.route('/check_updates', methods=['GET'])
def check_updates():
    """Prüft, ob Updates verfügbar sind"""
    try:
        from updater import check_for_updates
        update_data = check_for_updates()
        
        if update_data:
            return jsonify({
                "updateAvailable": True,
                "version": update_data["version"],
                "build": update_data["build"],
                "changes": update_data["changeLog"]
            })
        else:
            return jsonify({"updateAvailable": False})
    except Exception as e:
        return jsonify({"updateAvailable": False, "error": str(e)}), 500

@app.route('/update_system', methods=['POST'])
def update_system():
    """Führt ein Systemupdate durch"""
    try:
        from updater import update
        success = update()
        
        if success:
            # System nach erfolgreichem Update neustarten
            os.system('sudo reboot &')
            return jsonify({"success": True, "message": "Update erfolgreich installiert. System wird neu gestartet."})
        else:
            return jsonify({"success": False, "message": "Update konnte nicht installiert werden."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/')
def index():
    """Render die Webseite mit dem Videostream für Offline-Nutzung optimiert"""
    # Wir verwenden hier eine HTML-Datei, die beim Setup erstellt wurde
    html_template_path = os.path.join(static_folder, 'index.html')
    
    try:
        with open(html_template_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        # Fallback bei Kodierungsproblemen
        with open(html_template_path, 'rb') as f:
            content = f.read()
            return content.decode('utf-8', errors='replace')


@app.route('/set_roi', methods=['POST'])
def set_roi():
    """Region of Interest (ROI) hinzufügen"""
    global object_detection
    
    try:
        data = request.json
        
        # Sicherstellen, dass die Werte gültig sind
        x = max(0, min(int(data.get("x", 0)), object_detection.img_width - 1))
        y = max(0, min(int(data.get("y", 0)), object_detection.img_height - 1))
        width = max(10, min(int(data.get("width", object_detection.img_width)), object_detection.img_width - x))
        height = max(10, min(int(data.get("height", object_detection.img_height)), object_detection.img_height - y))
        
        # Minimale Größe sicherstellen (mind. 10x10 Pixel)
        if width < 10 or height < 10:
            return {"success": False, "error": "ROI zu klein (mind. 10x10 Pixel)"}, 400
        
        # Maximale Anzahl von ROIs begrenzen (z.B. auf 5)
        max_roi_count = 5
        
        with object_detection.roi_lock:
            # Prüfen, ob das Maximum bereits erreicht ist
            if len(object_detection.rois) >= max_roi_count:
                return {"success": False, "error": f"Maximale Anzahl von {max_roi_count} ROIs erreicht"}, 400
                
            # Neue ROI erstellen und hinzufügen
            new_roi = {
                "x": x,
                "y": y,
                "width": width,
                "height": height,
                "id": int(time.time() * 1000)  # Eindeutige ID basierend auf Zeitstempel
            }
            object_detection.rois.append(new_roi)
        
        # Logging für Debugging
        print(f"ROI #{len(object_detection.rois)} hinzugefügt: x={x}, y={y}, width={width}, height={height}")
        
        return {"success": True, "roi_id": new_roi["id"], "roi_count": len(object_detection.rois)}
    except Exception as e:
        print(f"Fehler beim Hinzufügen der ROI: {e}")
        return {"success": False, "error": str(e)}, 400



@app.route('/reset_roi', methods=['POST'])
def reset_roi():
    """Alle ROIs zurücksetzen/löschen"""
    global object_detection
    
    object_detection.clear_rois()
    print("Alle ROIs zurückgesetzt")
    
    return {"success": True, "roi_count": 0}

@app.route('/roi_status')
def roi_status():
    """Aktuellen ROI-Status zurückgeben"""
    global object_detection
    
    with object_detection.roi_lock:
        current_rois = [roi.copy() for roi in object_detection.rois]
    
    return {"rois": current_rois, "count": len(current_rois)}

# Neuer Endpunkt für Perspektivkorrektur
@app.route('/perspective_point', methods=['POST'])
def add_perspective_point():
    """Fügt einen Punkt für die Perspektivkorrektur hinzu"""
    global object_detection, config
    
    try:
        data = request.json
        x = int(data.get('x', 0))
        y = int(data.get('y', 0))
        
        with object_detection.perspective_lock:
            # Punkt hinzufügen oder ersetzen
            point_index = data.get('index')
            
            # Wenn ein Index angegeben wurde, diesen Punkt ersetzen oder einfügen
            if point_index is not None:
                point_index = int(point_index)
                # Liste erweitern falls nötig
                while len(object_detection.perspective_points) <= point_index:
                    object_detection.perspective_points.append([0, 0])
                object_detection.perspective_points[point_index] = [x, y]
            else:
                # Sonst Punkte zyklisch hinzufügen (maximal 4)
                if len(object_detection.perspective_points) >= 4:
                    object_detection.perspective_points = []
                object_detection.perspective_points.append([x, y])
            
            # Matrix neu berechnen, wenn alle 4 Punkte vorhanden sind
            if len(object_detection.perspective_points) == 4:
                src_points = np.array(object_detection.perspective_points, dtype=np.float32)
                dst_width = 1000
                dst_height = 1000
                dst_points = np.array([
                    [0, 0],
                    [dst_width, 0],
                    [dst_width, dst_height],
                    [0, dst_height]
                ], dtype=np.float32)
                object_detection.perspective_matrix = cv2.getPerspectiveTransform(src_points, dst_points)
                
                # Speicher in Konfiguration
                config['perspective']['points'] = object_detection.perspective_points
                config['perspective']['matrix'] = object_detection.perspective_matrix.tolist()
                save_config(config)
            else:
                # Nur die Punkte speichern, wenn noch nicht alle vorhanden sind
                config['perspective']['points'] = object_detection.perspective_points
                save_config(config)
        
        # Antwort mit aktuellem Status
        return {
            "success": True, 
            "points": object_detection.perspective_points, 
            "complete": len(object_detection.perspective_points) == 4,
            "perspective_enabled": object_detection.perspective_enabled
        }
    
    except Exception as e:
        print(f"Fehler beim Hinzufügen des Perspektivpunkts: {e}")
        return {"success": False, "error": str(e)}, 400

@app.route('/perspective_reset', methods=['POST'])
def reset_perspective():
    """Setzt die Perspektivkorrektur zurück"""
    global object_detection, config
    
    with object_detection.perspective_lock:
        object_detection.perspective_points = []
        object_detection.perspective_matrix = None
        object_detection.perspective_enabled = False
        
        # Konfiguration aktualisieren
        config['perspective']['points'] = []
        config['perspective']['matrix'] = []
        config['perspective']['enabled'] = False
        
        # Konfiguration speichern (mit Fehlerbehandlung für Berechtigungsprobleme)
        try:
            success = save_config(config)
            if not success:
                print("WARNUNG: Konnte Perspektivkorrektur-Reset nicht in Konfigurationsdatei speichern")
                # Versuche mit sudo zu speichern (falls Berechtigungen fehlen)
                os.system(f'sudo bash -c \'echo \'{json.dumps(config, indent=2)}\' > {CONFIG_PATH}\'')
        except Exception as e:
            print(f"Fehler beim Speichern der Konfiguration nach Perspektivkorrektur-Reset: {e}")
    
    return {"success": True}

@app.route('/perspective_toggle', methods=['POST'])
def toggle_perspective():
    """Aktiviert oder deaktiviert die Perspektivkorrektur"""
    global object_detection, config
    
    # Nur umschalten, wenn eine Matrix vorhanden ist
    with object_detection.perspective_lock:
        if object_detection.perspective_matrix is not None:
            object_detection.perspective_enabled = not object_detection.perspective_enabled
            
            # Konfiguration aktualisieren
            config['perspective']['enabled'] = object_detection.perspective_enabled
            save_config(config)
            
            return {"success": True, "enabled": object_detection.perspective_enabled}
        else:
            return {"success": False, "error": "Keine Perspektivmatrix vorhanden. Bitte zuerst kalibrieren."}, 400

@app.route('/perspective_status')
def perspective_status():
    """Gibt den aktuellen Status der Perspektivkorrektur zurück"""
    global object_detection
    
    with object_detection.perspective_lock:
        return {
            "points": object_detection.perspective_points,
            "complete": len(object_detection.perspective_points) == 4,
            "enabled": object_detection.perspective_enabled
        }


# Neue Route zur Hilfedatei hinzufügen 
@app.route('/help')
def help_page():
    """Hilfedatei anzeigen"""
    help_html_path = os.path.join(static_folder, 'help.html')
    
    try:
        with open(help_html_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        # Fallback bei Kodierungsproblemen
        with open(help_html_path, 'rb') as f:
            content = f.read()
            return content.decode('utf-8', errors='replace')
    except FileNotFoundError:
        # Falls die Datei nicht existiert, mit send_from_directory versuchen
        return send_from_directory(static_folder, 'help.html')

# Dashboard für Mehrfach-Kamera-Übersicht
@app.route('/dashboard')
def dashboard_page():
    """Dashboard für die Kameraübersicht anzeigen"""
    return send_from_directory(static_folder, 'dashboard.html')


@app.route('/video_feed')
def video_feed():
    """Video-Stream als Response zurückgeben"""
    return Response(generate_frames(),
                   mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/toggle_detection', methods=['POST'])
def toggle_detection():
    """Objekterkennung ein-/ausschalten"""
    global object_detection
    
    # Objektzähler und Markierungen zurücksetzen
    object_detection.clear_detected_holes()
    
    # Aktuelle Einstellung umkehren
    new_state = not object_detection.detection_enabled
    
    # Bei Deaktivierung auch die Referenzlöcher zurücksetzen
    if not new_state:
        object_detection.reset_reference_holes()
    
    # Aktiviert/Deaktiviert die Objekterkennung - setzt dabei automatisch
    # Referenzlöcher bei Aktivierung
    object_detection.set_detection_enabled(new_state)
    
    return {"enabled": new_state}

@app.route('/detection_status')
def detection_status():
    """Aktuellen Status der Objekterkennung zurückgeben"""
    global object_detection
    
    status = object_detection.detection_enabled
    
    return {"enabled": status}

# Kamera-Status überprüfen
@app.route('/camera_status')
def camera_status():
    """Überprüft, ob die Kamera online und funktionsfähig ist"""
    global frame_buffer
    
    # Überprüfen, ob ein Frame-Buffer vorhanden ist (bedeutet Kamera funktioniert)
    with frame_lock:
        camera_online = frame_buffer is not None
    
    return {"online": camera_online}

# Anzeigeart umschalten (nur letzten Treffer oder alle Treffer)
@app.route('/toggle_display_mode', methods=['POST'])
def toggle_display_mode():
    """Schaltet zwischen 'Nur letzter Treffer' und 'Alle Treffer' um"""
    global object_detection, config
    
    # Aktuellen Zustand umkehren
    new_state = not object_detection.show_only_last_hole
    
    # Anzeigemodus setzen
    object_detection.set_display_mode(new_state)
    
    # Konfiguration aktualisieren
    config['visualization']['showOnlyLastHole'] = new_state
    save_config(config)
    
    return {"enabled": new_state, "mode": "Nur letzter Treffer" if new_state else "Alle Treffer"}

# Status des Anzeigemodus abrufen
@app.route('/display_mode_status')
def display_mode_status():
    """Gibt den aktuellen Anzeigemodus zurück"""
    global object_detection
    
    mode = object_detection.show_only_last_hole
    
    return {"enabled": mode, "mode": "Nur letzter Treffer" if mode else "Alle Treffer"}

    
    
    
# Neuer Endpunkt zum Abrufen der erkannten Löcher
@app.route('/detected_holes')
def get_detected_holes():
    """Liste der aktuell erkannten Einschusslöcher zurückgeben"""
    global object_detection
    
    with object_detection.detected_holes_lock:
        holes_copy = []
        # Tiefe Kopie erstellen und dabei das neueste Loch markieren
        for hole in object_detection.detected_holes:
            hole_copy = hole.copy()
            # Ist-neuestes-Flag entfernen, falls es existiert
            if 'is_newest' in hole_copy:
                del hole_copy['is_newest']
            holes_copy.append(hole_copy)
        
        # Wenn Einschusslöcher vorhanden sind, markiere das neueste basierend auf
        # dem Zeitstempel und der Positionserkennung
        if holes_copy:
            # Neuestes Loch markieren
            for i, hole in enumerate(holes_copy):
                # Hole ist_newest_hole aus dem letzten Zeichen des Timestamps
                hole_center_x = hole["x"] + hole["width"] / 2
                hole_center_y = hole["y"] + hole["height"] / 2
                
                # Prüfe alle anderen Löcher
                is_newest = True
                for other_hole in holes_copy:
                    if hole == other_hole:
                        continue
                        
                    other_center_x = other_hole["x"] + other_hole["width"] / 2
                    other_center_y = other_hole["y"] + other_hole["height"] / 2
                    
                    # Wenn ein anderes Loch näher am neuesten Zeitstempel ist
                    if abs(other_center_x - hole_center_x) < 15 and abs(other_center_y - hole_center_y) < 15:
                        is_newest = False
                        break
                        
                if is_newest:
                    hole['is_newest'] = True
                    break
                    
            # Wenn kein Loch als neuestes markiert wurde, markiere das letzte
            if not any('is_newest' in h for h in holes_copy) and holes_copy:
                holes_copy[-1]['is_newest'] = True
    
    return {"holes": holes_copy}

# PDF-Bericht generieren
@app.route('/generate_pdf_report', methods=['POST'])
def generate_pdf_report():
    """Generiert einen PDF-Bericht mit den erkannten Einschusslöchern"""
    try:
        data = request.json
        
        # PDFReportGenerator aus dem ausgelagerten Modul verwenden
        pdf_generator = PDFReportGenerator(config)
        result = pdf_generator.generate_report(data)
        
        return result
    
    except Exception as e:
        print(f"Fehler beim Erstellen des PDF-Berichts: {e}")
        return {"success": False, "error": str(e)}, 500

# Zum Herunterladen der generierten PDF-Berichte und anderen statischen Dateien
@app.route('/static/<path:filename>')
def download_file(filename):
    return send_from_directory(static_folder, filename)

# Service Worker Route
@app.route('/static/service-worker.js')
def service_worker():
    """Sendet den Service Worker mit den richtigen MIME-Typen"""
    response = send_from_directory(static_folder, 'service-worker.js')
    response.headers['Content-Type'] = 'application/javascript'
    return response

# Manifest Route
@app.route('/static/manifest.webmanifest')
def manifest():
    """Sendet das Web App Manifest mit den richtigen MIME-Typen"""
    response = send_from_directory(static_folder, 'manifest.webmanifest')
    response.headers['Content-Type'] = 'application/manifest+json'
    return response

# Einstellungsseite
@app.route('/settings')
def settings_page():
    """Einstellungsseite anzeigen"""
    settings_html_path = os.path.join(static_folder, 'settings.html')
    
    try:
        with open(settings_html_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        # Fallback bei Kodierungsproblemen
        with open(settings_html_path, 'rb') as f:
            content = f.read()
            return content.decode('utf-8', errors='replace')

# Archivseite
@app.route('/archive')
def archive_page():
    """Archivseite anzeigen"""
    archive_html_path = os.path.join(static_folder, 'archive.html')
    
    try:
        with open(archive_html_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        # Fallback bei Kodierungsproblemen
        with open(archive_html_path, 'rb') as f:
            content = f.read()
            return content.decode('utf-8', errors='replace')

# API zum Aktualisieren der Einstellungen
@app.route('/update_settings', methods=['POST'])
def update_settings():
    """Einstellungen aktualisieren"""
    global config, object_detection
    
    try:
        data = request.json
        
        # Konfiguration aktualisieren
        if 'visualization' in data:
            vis_data = data['visualization']
            config['visualization']['displayScatterCircle'] = vis_data.get('displayScatterCircle', config['visualization']['displayScatterCircle'])
            config['visualization']['scatterCircleColor'] = list(vis_data.get('scatterCircleColor', config['visualization']['scatterCircleColor']))
            config['visualization']['scatterCircleThickness'] = vis_data.get('scatterCircleThickness', config['visualization']['scatterCircleThickness'])
            config['visualization']['roiBorderThickness'] = vis_data.get('roiBorderThickness', config['visualization'].get('roiBorderThickness', 2))
            config['visualization']['holeMarkerThickness'] = vis_data.get('holeMarkerThickness', config['visualization'].get('holeMarkerThickness', 2))
            config['visualization']['roiDarkeningLevel'] = vis_data.get('roiDarkeningLevel', config['visualization'].get('roiDarkeningLevel', 50))
            config['visualization']['holeColor'] = list(vis_data.get('holeColor', config['visualization']['holeColor']))
            config['visualization']['lastHoleColor'] = list(vis_data.get('lastHoleColor', config['visualization']['lastHoleColor']))
            config['visualization']['showOnlyLastHole'] = vis_data.get('showOnlyLastHole', config['visualization'].get('showOnlyLastHole', False))
        
        # Stream-Einstellungen
        sharpness_changed = False
        if 'stream' in data:
            stream_data = data['stream']
            config['stream']['jpegQuality'] = stream_data.get('jpegQuality', config['stream']['jpegQuality'])
            config['stream']['grayscale'] = stream_data.get('grayscale', config['stream']['grayscale'])
            old_sharpness = config['stream']['sharpness']
            new_sharpness = stream_data.get('sharpness', old_sharpness)
            
            # Prüfen, ob sich der Sharpness-Wert geändert hat
            if new_sharpness != old_sharpness:
                config['stream']['sharpness'] = new_sharpness
                sharpness_changed = True
        
        # Kamera-Einstellungen
        if 'camera' in data:
            camera_data = data['camera']
            config['camera']['confidenceThreshold'] = camera_data.get('confidenceThreshold', config['camera']['confidenceThreshold'])
            config['camera']['fps'] = camera_data.get('fps', config['camera']['fps'])
            
            # Auflösungsänderungen erfordern einen Neustart der Anwendung
            resolution = camera_data.get('resolution', config['camera']['resolution'])
            if resolution != config['camera']['resolution']:
                config['camera']['resolution'] = resolution
                # Hier könnten Sie eine Nachricht zurückgeben, 
                # dass ein Neustart erforderlich ist, um die Auflösung anzuwenden
        
        # Interface-Einstellungen
        if 'interface' in data:
            interface_data = data['interface']
            config['interface']['showTimestamp'] = interface_data.get('showTimestamp', config['interface']['showTimestamp'])
            config['interface']['showCoordinates'] = interface_data.get('showCoordinates', config['interface']['showCoordinates'])
            config['interface']['darkMode'] = interface_data.get('darkMode', config['interface']['darkMode'])
            
        # Perspektiv-Einstellungen
        if 'perspective' in data:
            perspective_data = data['perspective']
            
            with object_detection.perspective_lock:
                # Prüfen, ob die Punkte zurückgesetzt werden sollen (leeres Array)
                if 'points' in perspective_data and not perspective_data['points']:
                    # Perspektivkorrektur deaktivieren
                    object_detection.perspective_enabled = False
                    config['perspective']['enabled'] = False
                    
                    # Perspektivpunkte und Matrix zurücksetzen
                    object_detection.perspective_points = []
                    object_detection.perspective_matrix = None
                    config['perspective']['points'] = []
                    config['perspective']['matrix'] = []
                    print("Perspektivkorrektur zurückgesetzt")
                else:
                    # Normaler Update-Fall
                    # Nur aktivieren/deaktivieren, wenn übermittelt
                    if 'enabled' in perspective_data:
                        object_detection.perspective_enabled = perspective_data.get('enabled')
                        config['perspective']['enabled'] = object_detection.perspective_enabled
                    
                    # Wenn neue Punkte übermittelt wurden und genau 4 vorhanden sind, Matrix aktualisieren
                    if 'points' in perspective_data and len(perspective_data['points']) == 4:
                        object_detection.perspective_points = perspective_data['points']
                        config['perspective']['points'] = object_detection.perspective_points
                        
                        # Neue Transformationsmatrix berechnen
                        src_points = np.array(object_detection.perspective_points, dtype=np.float32)
                        dst_width = 1000
                        dst_height = 1000
                        dst_points = np.array([
                            [0, 0],
                            [dst_width, 0],
                            [dst_width, dst_height],
                            [0, dst_height]
                        ], dtype=np.float32)
                        object_detection.perspective_matrix = cv2.getPerspectiveTransform(src_points, dst_points)
                        
                        # Matrix in serialisierbares Format umwandeln für die Konfigurationsdatei
                        config['perspective']['matrix'] = object_detection.perspective_matrix.tolist() if object_detection.perspective_matrix is not None else []
        
        # Konfiguration speichern
        save_config(config)
        
        # Aktualisiere die Konfiguration im ObjectDetector
        object_detection.update_config(config)
        
        return {"success": True, "settings": config}
    except Exception as e:
        print(f"Fehler beim Aktualisieren der Einstellungen: {e}")
        return {"success": False, "error": str(e)}, 400

# API zum Abrufen der aktuellen Einstellungen
@app.route('/get_settings')
def get_settings():
    """Aktuelle Einstellungen abrufen"""
    return config

# System-Aktionen zum Neustarten und Herunterfahren
@app.route('/system_action/<action>', methods=['POST'])
def system_action(action):
    """Führt Systemaktionen aus (Neustart, Herunterfahren)"""
    if action not in ['restart', 'shutdown']:
        return jsonify({"success": False, "error": "Unbekannte Aktion"}), 400
    
    try:
        if action == 'restart':
            # Raspberry Pi neustarten
            os.system('sudo reboot')
            return jsonify({"success": True})
        elif action == 'shutdown':
            # Raspberry Pi herunterfahren
            os.system('sudo shutdown now')
            return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    

# API zum Auflisten von Dateien
@app.route('/list_files')
def list_files():
    """Listet alle PDF-Berichte auf"""
    try:
        # Pfade für die Dateiordner
        temp_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp')
        static_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
        
        print(f"Suche PDF-Berichte in Verzeichnissen: temp={temp_path}, static={static_path}")
        
        # Dateien sammeln
        files = []
        
        # PDF-Berichte aus dem temp-Ordner
        pdf_pattern = os.path.join(temp_path, 'bericht_*.pdf')
        temp_files = glob.glob(pdf_pattern)
        print(f"Gefundene PDF-Dateien im temp-Ordner: {len(temp_files)}")
        
        for pdf_file in temp_files:
            filename = os.path.basename(pdf_file)
            path = f'/temp/{filename}'
            stats = os.stat(pdf_file)
            print(f"Verarbeite Datei: {pdf_file}")
            
            # Erstelldatum aus dem Dateinamen extrahieren (Format: bericht_YYYYMMDD_HHMMSS.pdf)
            date_parts = filename.replace('bericht_', '').replace('.pdf', '').split('_')
            if len(date_parts) == 2:
                try:
                    year = date_parts[0][:4]
                    month = date_parts[0][4:6]
                    day = date_parts[0][6:8]
                    hour = date_parts[1][:2]
                    minute = date_parts[1][2:4]
                    second = date_parts[1][4:6]
                    date_str = f"{year}-{month}-{day}T{hour}:{minute}:{second}"
                except:
                    date_str = datetime.datetime.fromtimestamp(stats.st_mtime).isoformat()
            else:
                date_str = datetime.datetime.fromtimestamp(stats.st_mtime).isoformat()
            
            files.append({
                'name': filename,
                'path': path,
                'size': stats.st_size,
                'date': date_str,
                'type': 'pdf'
            })
        
        # PDF-Berichte aus dem static-Ordner
        pdf_pattern = os.path.join(static_path, 'bericht_*.pdf')
        static_files = glob.glob(pdf_pattern)
        print(f"Gefundene PDF-Dateien im static-Ordner: {len(static_files)}")
        
        for pdf_file in static_files:
            filename = os.path.basename(pdf_file)
            path = f'/static/{filename}'
            stats = os.stat(pdf_file)
            print(f"Verarbeite Datei: {pdf_file}")
            
            # Erstelldatum aus dem Dateinamen extrahieren (Format: bericht_YYYYMMDD_HHMMSS.pdf)
            date_parts = filename.replace('bericht_', '').replace('.pdf', '').split('_')
            if len(date_parts) == 2:
                try:
                    year = date_parts[0][:4]
                    month = date_parts[0][4:6]
                    day = date_parts[0][6:8]
                    hour = date_parts[1][:2]
                    minute = date_parts[1][2:4]
                    second = date_parts[1][4:6]
                    date_str = f"{year}-{month}-{day}T{hour}:{minute}:{second}"
                except:
                    date_str = datetime.datetime.fromtimestamp(stats.st_mtime).isoformat()
            else:
                date_str = datetime.datetime.fromtimestamp(stats.st_mtime).isoformat()
            
            files.append({
                'name': filename,
                'path': path,
                'size': stats.st_size,
                'date': date_str,
                'type': 'pdf'
            })
        
        print(f"Insgesamt {len(files)} Dateien gefunden")
        return {"files": files, "count": len(files)}
    except Exception as e:
        print(f"Fehler beim Auflisten der Dateien: {e}")
        import traceback
        traceback.print_exc()
        return {"files": [], "count": 0, "error": str(e)}, 500

# API zum Löschen einer Datei
@app.route('/delete_file', methods=['POST'])
def delete_file():
    """Löscht eine PDF-Datei"""
    try:
        data = request.json
        file_path = data.get('path')
        
        if not file_path:
            return {"success": False, "error": "Kein Dateipfad angegeben"}, 400
        
        print(f"Löschanfrage für Datei: {file_path}")
        
        # Basis-Verzeichnisse
        temp_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp')
        static_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
        
        full_path = None
        
        # Sicherheitscheck: Nur PDF-Berichte in zugelassenen Verzeichnissen löschen
        if file_path.startswith('/temp/bericht_') and file_path.endswith('.pdf'):
            full_path = os.path.join(temp_path, file_path.replace('/temp/', ''))
            print(f"Lösche Datei aus temp-Verzeichnis: {full_path}")
        elif file_path.startswith('/static/bericht_') and file_path.endswith('.pdf'):
            full_path = os.path.join(static_path, file_path.replace('/static/', ''))
            print(f"Lösche Datei aus static-Verzeichnis: {full_path}")
        else:
            return {"success": False, "error": "Ungültiger Dateipfad oder Dateityp"}, 400
        
        # Datei löschen
        if full_path and os.path.exists(full_path):
            os.remove(full_path)
            print(f"Datei erfolgreich gelöscht: {full_path}")
            return {"success": True}
        else:
            print(f"Datei nicht gefunden: {full_path}")
            return {"success": False, "error": "Datei nicht gefunden"}, 404
    
    except Exception as e:
        print(f"Fehler beim Löschen der Datei: {e}")
        import traceback
        traceback.print_exc()
        return {"success": False, "error": str(e)}, 500

# API zum Löschen mehrerer Dateien
@app.route('/delete_files', methods=['POST'])
def delete_files():
    """Löscht mehrere PDF-Dateien"""
    try:
        data = request.json
        file_paths = data.get('paths', [])
        
        if not file_paths:
            return {"success": False, "error": "Keine Dateipfade angegeben"}, 400
        
        # Basis-Verzeichnisse
        temp_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp')
        static_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
        
        print(f"Löschauftrag für {len(file_paths)} Dateien")
        
        success_count = 0
        error_count = 0
        
        for file_path in file_paths:
            full_path = None
            
            # Sicherheitscheck: Nur PDF-Berichte in zugelassenen Verzeichnissen löschen
            if file_path.startswith('/temp/bericht_') and file_path.endswith('.pdf'):
                full_path = os.path.join(temp_path, file_path.replace('/temp/', ''))
                print(f"Lösche Datei aus temp-Verzeichnis: {full_path}")
            elif file_path.startswith('/static/bericht_') and file_path.endswith('.pdf'):
                full_path = os.path.join(static_path, file_path.replace('/static/', ''))
                print(f"Lösche Datei aus static-Verzeichnis: {full_path}")
            else:
                print(f"Ungültiger Dateipfad: {file_path}")
                error_count += 1
                continue
            
            # Datei löschen
            if full_path and os.path.exists(full_path):
                os.remove(full_path)
                success_count += 1
                print(f"Datei gelöscht: {full_path}")
            else:
                error_count += 1
                print(f"Datei nicht gefunden: {full_path}")
        
        return {
            "success": True,
            "deleted": success_count,
            "errors": error_count
        }
    
    except Exception as e:
        print(f"Fehler beim Löschen der Dateien: {e}")
        import traceback
        traceback.print_exc()
        return {"success": False, "error": str(e)}, 500

# API zum Löschen aller Dateien
@app.route('/delete_all_files', methods=['POST'])
def delete_all_files():
    """Löscht alle PDF-Berichte"""
    try:
        data = request.json
        file_type = data.get('type', 'all')
        
        success_count = 0
        error_count = 0
        
        # Basis-Verzeichnisse
        temp_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp')
        static_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
        
        print("Löschauftrag für alle PDF-Berichte")
        
        # PDF-Berichte aus dem temp-Ordner löschen
        print(f"Lösche PDF-Berichte im temp-Verzeichnis")
        pdf_pattern = os.path.join(temp_path, 'bericht_*.pdf')
        for pdf_file in glob.glob(pdf_pattern):
            try:
                os.remove(pdf_file)
                success_count += 1
                print(f"Datei gelöscht: {pdf_file}")
            except Exception as e:
                error_count += 1
                print(f"Fehler beim Löschen von {pdf_file}: {e}")
        
        # PDF-Berichte aus dem static-Ordner löschen
        print(f"Lösche PDF-Berichte im static-Verzeichnis")
        pdf_pattern = os.path.join(static_path, 'bericht_*.pdf')
        for pdf_file in glob.glob(pdf_pattern):
            try:
                os.remove(pdf_file)
                success_count += 1
                print(f"Datei gelöscht: {pdf_file}")
            except Exception as e:
                error_count += 1
                print(f"Fehler beim Löschen von {pdf_file}: {e}")
        
        return {
            "success": True,
            "deleted": success_count,
            "errors": error_count
        }
    
    except Exception as e:
        print(f"Fehler beim Löschen aller Dateien: {e}")
        import traceback
        traceback.print_exc()
        return {"success": False, "error": str(e)}, 500


# Route für temporäre Dateien
@app.route('/temp/<path:filename>')
def temp_file(filename):
    """Sendet temporäre Dateien"""
    temp_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp')
    return send_from_directory(temp_dir, filename)

if __name__ == "__main__":
    try:
        # Anwendung initialisieren
        
        print("Initialisiere Anwendung...")
        
        # Stellen sicher, dass der statische Ordner und das Favicon existieren
        # Dies wurde bereits oben ausgeführt
        
        # Objekterkennungklasse aus dem ausgelagerten Modul initialisieren
        from object_detection import ObjectDetector
        object_detection = ObjectDetector(MODEL_PATH, config)
        
        # Einstellung "nur letzte Treffer anzeigen" aus der Konfiguration übernehmen
        if "showOnlyLastHole" in config.get("visualization", {}):
            object_detection.show_only_last_hole = config["visualization"]["showOnlyLastHole"]
        
        # Thread für die Bildverarbeitung starten
        process_thread = threading.Thread(target=object_detection.capture_frames)
        process_thread.daemon = True
        process_thread.start()
        
        # Flask-Server starten
        print("Webserver wird gestartet... öffne http://[RPI_IP]:5000 im Browser")
        print(f"Favicon ist verfügbar unter {static_folder}/favicon.svg")
        
        # Startparameter für die Bildschärfe ausgeben
        print(f"Aktuelle Bildschärfe: {config['stream']['sharpness']} (Bereich: -10 bis 10)")
        
        app.run(host='0.0.0.0', port=5000, threaded=True)
        
    except KeyboardInterrupt:
        print("Programm wird beendet")
    except Exception as e:
        print(f"Fehler: {e}")
